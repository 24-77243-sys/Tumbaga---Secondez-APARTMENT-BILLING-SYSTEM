"""
Enums for the apartment billing system
"""

from enum import Enum


class BillingStatus(Enum):
    """Billing status enum"""
    PENDING = "pending"
    UNPAID = "unpaid"
    PARTIALLY_PAID = "partially_paid"
    PAID = "paid"
    OVERDUE = "overdue"


class PaymentMethod(Enum):
    """Payment method enum"""
    CASH = "cash"
    ADVANCE = "advance"
