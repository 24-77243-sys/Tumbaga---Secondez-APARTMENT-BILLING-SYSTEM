"""
Repository layer for data persistence
Based on original backend.py DatabaseConnection, Repository, and concrete repositories
"""

import sqlite3
import time
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from .models import Entity, Tenant, Unit, Billing, TenantBilling, Payment


class DatabaseConnection:
    """Database connection manager with retry logic for locks"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.max_retries = 5
        self.retry_delay = 0.5
    
    def get_connection(self) -> sqlite3.Connection:
        """Get database connection with timeout handling"""
        conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        # Enable WAL mode for better concurrency
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")  # 30 second timeout
        return conn
    
    def execute_query(self, query: str, params: tuple = ()) -> List[sqlite3.Row]:
        """Execute a SELECT query"""
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            results = cursor.fetchall()
            return results
        finally:
            conn.close()
    
    def execute_update(self, query: str, params: tuple = ()) -> int:
        """Execute INSERT/UPDATE/DELETE query with retry logic"""
        retries = 0
        while retries < self.max_retries:
            try:
                conn = self.get_connection()
                try:
                    cursor = conn.cursor()
                    cursor.execute(query, params)
                    conn.commit()
                    lastrowid = cursor.lastrowid
                    return lastrowid
                finally:
                    conn.close()
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e) and retries < self.max_retries - 1:
                    retries += 1
                    time.sleep(self.retry_delay * retries)  # Exponential backoff
                else:
                    raise


class Repository(ABC):
    """Abstract Repository class (abstraction layer)"""
    
    def __init__(self, db_connection: DatabaseConnection):
        self.db = db_connection
    
    @abstractmethod
    def create(self, entity: Entity) -> int:
        """Create entity"""
        pass
    
    @abstractmethod
    def read(self, id: int) -> Optional[Entity]:
        """Read entity by ID"""
        pass
    
    @abstractmethod
    def read_all(self) -> List[Entity]:
        """Read all entities"""
        pass
    
    @abstractmethod
    def update(self, id: int, entity: Entity) -> bool:
        """Update entity"""
        pass
    
    @abstractmethod
    def delete(self, id: int) -> bool:
        """Delete entity"""
        pass


# ========================= CONCRETE REPOSITORIES (POLYMORPHISM) =========================
class TenantRepository(Repository):
    """Repository for Tenant CRUD operations"""
    
    def create(self, entity: Tenant) -> int:
        if not entity.validate():
            raise ValueError("Invalid tenant data")
        
        query = """
            INSERT INTO tenants (full_name, contact_number, email, unit_number, 
                                rent_amount, move_in_date, notes, address, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        params = (
            entity.full_name, entity._contact_number, entity.email,
            entity._unit_number, entity.rent_amount, entity._move_in_date,
            entity._notes, entity.address, int(entity.active)
        )
        return self.db.execute_update(query, params)
    
    def read(self, id: int) -> Optional[Tenant]:
        query = "SELECT * FROM tenants WHERE id = ?"
        results = self.db.execute_query(query, (id,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Tenant(
            full_name=row['full_name'],
            contact_number=row['contact_number'],
            email=row['email'],
            unit_number=row['unit_number'],
            rent_amount=row['rent_amount'],
            move_in_date=row['move_in_date'],
            notes=row['notes'],
            address=row.get('address', ''),
            active=bool(row['active']),
            id=row['id']
        )
    
    def read_all(self) -> List[Tenant]:
        query = "SELECT * FROM tenants"
        results = self.db.execute_query(query)
        
        tenants = []
        for row in results:
            row_dict = dict(row)
            tenants.append(Tenant(
                full_name=row_dict['full_name'],
                contact_number=row_dict['contact_number'],
                email=row_dict['email'],
                unit_number=row_dict['unit_number'],
                rent_amount=row_dict['rent_amount'],
                move_in_date=row_dict['move_in_date'],
                notes=row_dict['notes'],
                address=row_dict.get('address', ''),
                active=bool(row['active']),
                id=row['id']
            ))
        return tenants
    
    def read_by_unit(self, unit_number: str) -> Optional[Tenant]:
        """Read tenant by unit number"""
        query = "SELECT * FROM tenants WHERE unit_number = ? AND active = 1"
        results = self.db.execute_query(query, (unit_number,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Tenant(
            full_name=row['full_name'],
            contact_number=row['contact_number'],
            email=row['email'],
            unit_number=row['unit_number'],
            rent_amount=row['rent_amount'],
            move_in_date=row['move_in_date'],
            notes=row['notes'],
            address=row.get('address', ''),
            active=bool(row['active']),
            id=row['id']
        )
    
    def update(self, id: int, entity: Tenant) -> bool:
        if not entity.validate():
            raise ValueError("Invalid tenant data")
        
        query = """
            UPDATE tenants
            SET full_name = ?, contact_number = ?, email = ?, unit_number = ?,
                rent_amount = ?, move_in_date = ?, notes = ?, address = ?, active = ?
            WHERE id = ?
        """
        params = (
            entity.full_name, entity._contact_number, entity.email,
            entity._unit_number, entity.rent_amount, entity._move_in_date,
            entity._notes, entity.address, int(entity.active), id
        )
        self.db.execute_update(query, params)
        return True
    
    def delete(self, id: int) -> bool:
        query = "DELETE FROM tenants WHERE id = ?"
        self.db.execute_update(query, (id,))
        return True


class UnitRepository(Repository):
    """Repository for Unit CRUD operations"""
    
    def create(self, entity: Unit) -> int:
        if not entity.validate():
            raise ValueError("Invalid unit data")
        
        query = """
            INSERT INTO units (unit_number, default_rent, occupied, max_tenants)
            VALUES (?, ?, ?, ?)
        """
        params = (entity.unit_number, entity.default_rent, int(entity.occupied), entity.max_tenants)
        return self.db.execute_update(query, params)
    
    def read(self, id: int) -> Optional[Unit]:
        query = "SELECT id, unit_number, default_rent, occupied, max_tenants FROM units WHERE id = ?"
        results = self.db.execute_query(query, (id,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Unit(
            unit_number=row['unit_number'],
            default_rent=row['default_rent'],
            occupied=bool(row['occupied']),
            max_tenants=row.get('max_tenants', 2),
            id=row['id']
        )
    
    def read_by_unit_number(self, unit_number: str) -> Optional[Unit]:
        """Read unit by unit number"""
        query = "SELECT id, unit_number, default_rent, occupied, max_tenants FROM units WHERE unit_number = ?"
        results = self.db.execute_query(query, (unit_number,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Unit(
            unit_number=row['unit_number'],
            default_rent=row['default_rent'],
            occupied=bool(row['occupied']),
            max_tenants=row.get('max_tenants', 2),
            id=row['id']
        )
    
    def read_all(self) -> List[Unit]:
        query = "SELECT id, unit_number, default_rent, occupied, max_tenants FROM units"
        results = self.db.execute_query(query)
        
        units = []
        for row in results:
            row_dict = dict(row)
            units.append(Unit(
                unit_number=row_dict['unit_number'],
                default_rent=row_dict['default_rent'],
                occupied=bool(row_dict['occupied']),
                max_tenants=row_dict.get('max_tenants', 2),
                id=row_dict['id']
            ))
        return units
    
    def update(self, id: int, entity: Unit) -> bool:
        if not entity.validate():
            raise ValueError("Invalid unit data")
        
        query = """
            UPDATE units
            SET unit_number = ?, default_rent = ?, occupied = ?, max_tenants = ?
            WHERE id = ?
        """
        params = (entity.unit_number, entity.default_rent, int(entity.occupied), entity.max_tenants, id)
        self.db.execute_update(query, params)
        return True
    
    def delete(self, id: int) -> bool:
        query = "DELETE FROM units WHERE id = ?"
        self.db.execute_update(query, (id,))
        return True


class BillingRepository(Repository):
    """Repository for Billing CRUD operations"""
    
    def create(self, entity: Billing) -> int:
        if not entity.validate():
            raise ValueError("Invalid billing data")
        
        query = """
            INSERT INTO billings (unit_number, billing_month, due_date,
                                 total_water, total_electricity, total_wifi, rent)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """
        params = (
            entity._unit_number, entity._billing_month, entity._due_date,
            entity._total_water, entity._total_electricity, entity._total_wifi,
            entity._rent
        )
        return self.db.execute_update(query, params)
    
    def read(self, id: int) -> Optional[Billing]:
        query = "SELECT * FROM billings WHERE id = ?"
        results = self.db.execute_query(query, (id,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Billing(
            unit_number=row['unit_number'],
            billing_month=row['billing_month'],
            due_date=row['due_date'],
            total_water=row['total_water'],
            total_electricity=row['total_electricity'],
            total_wifi=row['total_wifi'],
            rent=row['rent'],
            id=row['id']
        )
    
    def read_all(self) -> List[Billing]:
        query = "SELECT * FROM billings"
        results = self.db.execute_query(query)
        
        billings = []
        for row in results:
            row_dict = dict(row)
            billings.append(Billing(
                unit_number=row_dict['unit_number'],
                billing_month=row_dict['billing_month'],
                due_date=row_dict['due_date'],
                total_water=row_dict['total_water'],
                total_electricity=row_dict['total_electricity'],
                total_wifi=row_dict['total_wifi'],
                rent=row_dict['rent'],
                id=row_dict['id']
            ))
        return billings
    
    def read_by_unit_and_month(self, unit_number: str, billing_month: str) -> Optional[Billing]:
        """Read billing by unit and month"""
        query = "SELECT * FROM billings WHERE unit_number = ? AND billing_month = ?"
        results = self.db.execute_query(query, (unit_number, billing_month))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Billing(
            unit_number=row['unit_number'],
            billing_month=row['billing_month'],
            due_date=row['due_date'],
            total_water=row['total_water'],
            total_electricity=row['total_electricity'],
            total_wifi=row['total_wifi'],
            rent=row['rent'],
            id=row['id']
        )
    
    def update(self, id: int, entity: Billing) -> bool:
        if not entity.validate():
            raise ValueError("Invalid billing data")
        
        query = """
            UPDATE billings
            SET unit_number = ?, billing_month = ?, due_date = ?,
                total_water = ?, total_electricity = ?, total_wifi = ?, rent = ?
            WHERE id = ?
        """
        params = (
            entity._unit_number, entity._billing_month, entity._due_date,
            entity._total_water, entity._total_electricity, entity._total_wifi,
            entity._rent, id
        )
        self.db.execute_update(query, params)
        return True
    
    def delete(self, id: int) -> bool:
        query = "DELETE FROM billings WHERE id = ?"
        self.db.execute_update(query, (id,))
        return True


class TenantBillingRepository(Repository):
    """Repository for TenantBilling CRUD operations"""
    
    def create(self, entity: TenantBilling) -> int:
        if not entity.validate():
            raise ValueError("Invalid tenant billing data")
        
        query = """
            INSERT INTO tenant_billings (tenant_id, billing_id, water_share,
                                        electricity_share, wifi_share, rent_share,
                                        manual_adjustment, total_amount, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        params = (
            entity._tenant_id, entity._billing_id, entity._water_share,
            entity._electricity_share, entity._wifi_share, entity._rent_share,
            entity._manual_adjustment, entity.total_amount, entity._status
        )
        return self.db.execute_update(query, params)
    
    def read(self, id: int) -> Optional[TenantBilling]:
        query = "SELECT * FROM tenant_billings WHERE id = ?"
        results = self.db.execute_query(query, (id,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return TenantBilling(
            tenant_id=row['tenant_id'],
            billing_id=row['billing_id'],
            water_share=row['water_share'],
            electricity_share=row['electricity_share'],
            wifi_share=row['wifi_share'],
            rent_share=row['rent_share'],
            manual_adjustment=row['manual_adjustment'],
            status=row['status'],
            id=row['id']
        )
    
    def read_all(self) -> List[TenantBilling]:
        query = "SELECT * FROM tenant_billings"
        results = self.db.execute_query(query)
        
        tenant_billings = []
        for row in results:
            row_dict = dict(row)
            tenant_billings.append(TenantBilling(
                tenant_id=row_dict['tenant_id'],
                billing_id=row_dict['billing_id'],
                water_share=row_dict['water_share'],
                electricity_share=row_dict['electricity_share'],
                wifi_share=row_dict['wifi_share'],
                rent_share=row_dict['rent_share'],
                manual_adjustment=row_dict['manual_adjustment'],
                status=row_dict['status'],
                id=row_dict['id']
            ))
        return tenant_billings
    
    def read_by_tenant_and_billing(self, tenant_id: int, billing_id: int) -> Optional[TenantBilling]:
        """Read tenant billing by tenant and billing"""
        query = "SELECT * FROM tenant_billings WHERE tenant_id = ? AND billing_id = ?"
        results = self.db.execute_query(query, (tenant_id, billing_id))
        
        if not results:
            return None
        
        row = dict(results[0])
        return TenantBilling(
            tenant_id=row['tenant_id'],
            billing_id=row['billing_id'],
            water_share=row['water_share'],
            electricity_share=row['electricity_share'],
            wifi_share=row['wifi_share'],
            rent_share=row['rent_share'],
            manual_adjustment=row['manual_adjustment'],
            status=row['status'],
            id=row['id']
        )
    
    def update(self, id: int, entity: TenantBilling) -> bool:
        if not entity.validate():
            raise ValueError("Invalid tenant billing data")
        
        query = """
            UPDATE tenant_billings
            SET tenant_id = ?, billing_id = ?, water_share = ?,
                electricity_share = ?, wifi_share = ?, rent_share = ?,
                manual_adjustment = ?, total_amount = ?, status = ?
            WHERE id = ?
        """
        params = (
            entity._tenant_id, entity._billing_id, entity._water_share,
            entity._electricity_share, entity._wifi_share, entity._rent_share,
            entity._manual_adjustment, entity.total_amount, entity._status, id
        )
        self.db.execute_update(query, params)
        return True
    
    def delete(self, id: int) -> bool:
        query = "DELETE FROM tenant_billings WHERE id = ?"
        self.db.execute_update(query, (id,))
        return True


class PaymentRepository(Repository):
    """Repository for Payment CRUD operations"""
    
    def create(self, entity: Payment) -> int:
        if not entity.validate():
            raise ValueError("Invalid payment data")
        
        query = """
            INSERT INTO payments (tenant_id, billing_month, amount_paid,
                                 payment_method, payment_date, tenant_billing_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """
        params = (
            entity._tenant_id, entity._billing_month, entity._amount_paid,
            entity._payment_method, entity._payment_date, entity._tenant_billing_id
        )
        return self.db.execute_update(query, params)
    
    def read(self, id: int) -> Optional[Payment]:
        query = "SELECT * FROM payments WHERE id = ?"
        results = self.db.execute_query(query, (id,))
        
        if not results:
            return None
        
        row = dict(results[0])
        return Payment(
            tenant_id=row['tenant_id'],
            billing_month=row['billing_month'],
            amount_paid=row['amount_paid'],
            payment_method=row['payment_method'],
            payment_date=row['payment_date'],
            tenant_billing_id=row.get('tenant_billing_id'),
            id=row['id']
        )
    
    def read_all(self) -> List[Payment]:
        query = "SELECT * FROM payments"
        results = self.db.execute_query(query)
        
        payments = []
        for row in results:
            row_dict = dict(row)
            payments.append(Payment(
                tenant_id=row_dict['tenant_id'],
                billing_month=row_dict['billing_month'],
                amount_paid=row_dict['amount_paid'],
                payment_method=row_dict['payment_method'],
                payment_date=row_dict['payment_date'],
                tenant_billing_id=row_dict.get('tenant_billing_id'),
                id=row_dict['id']
            ))
        return payments
    
    def read_by_tenant_and_month(self, tenant_id: int, billing_month: str) -> List[Payment]:
        """Read payments by tenant and month"""
        query = "SELECT * FROM payments WHERE tenant_id = ? AND billing_month = ?"
        results = self.db.execute_query(query, (tenant_id, billing_month))
        
        payments = []
        for row in results:
            row_dict = dict(row)
            payments.append(Payment(
                tenant_id=row_dict['tenant_id'],
                billing_month=row_dict['billing_month'],
                amount_paid=row_dict['amount_paid'],
                payment_method=row_dict['payment_method'],
                payment_date=row_dict['payment_date'],
                tenant_billing_id=row_dict.get('tenant_billing_id'),
                id=row_dict['id']
            ))
        return payments
    
    def update(self, id: int, entity: Payment) -> bool:
        if not entity.validate():
            raise ValueError("Invalid payment data")
        
        query = """
            UPDATE payments
            SET tenant_id = ?, billing_month = ?, amount_paid = ?,
                payment_method = ?, payment_date = ?, tenant_billing_id = ?
            WHERE id = ?
        """
        params = (
            entity._tenant_id, entity._billing_month, entity._amount_paid,
            entity._payment_method, entity._payment_date, entity._tenant_billing_id, id
        )
        self.db.execute_update(query, params)
        return True
    
    def delete(self, id: int) -> bool:
        query = "DELETE FROM payments WHERE id = ?"
        self.db.execute_update(query, (id,))
        return True

