"""
Authentication service for the apartment billing system
"""

import sqlite3
import hashlib
from typing import Optional, Dict


class AuthenticationService:
    """Service for user authentication"""
    
    def __init__(self, db_path: str = 'apartment_billing.db'):
        self.db_path = db_path
        self._initialize_admin()
    
    def _initialize_admin(self):
        """Initialize default admin user if not exists"""
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        cursor = conn.cursor()
        
        # Check if users table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cursor.fetchone():
            cursor.execute("""
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    full_name TEXT,
                    email TEXT,
                    role TEXT DEFAULT 'landlord',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
        
        # Check if admin user exists
        cursor.execute("SELECT id FROM users WHERE username = 'admin'")
        if not cursor.fetchone():
            admin_password_hash = self._hash_password('admin')
            cursor.execute("""
                INSERT INTO users (username, password_hash, full_name, email, role)
                VALUES (?, ?, ?, ?, ?)
            """, ('admin', admin_password_hash, 'Administrator', 'admin@example.com', 'landlord'))
            conn.commit()
        
        conn.close()
    
    @staticmethod
    def _hash_password(password: str) -> str:
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()

    def verify_login(self, username: str, password: str) -> bool:
        """Verify user login credentials"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT password_hash FROM users WHERE username = ?", (username,))
                result = cursor.fetchone()
            finally:
                conn.close()
            
            if not result:
                return False
            
            stored_hash = result[0]
            provided_hash = self._hash_password(password)
            return stored_hash == provided_hash
        except Exception:
            return False
    
    def get_user(self, username: str) -> Optional[Dict]:
        """Get user information"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT id, username, full_name, email, role FROM users WHERE username = ?", (username,))
                result = cursor.fetchone()
            finally:
                conn.close()
            
            if not result:
                return None
            
            return {
                'id': result[0],
                'username': result[1],
                'full_name': result[2],
                'email': result[3],
                'role': result[4]
            }
        except Exception:
            return None
