"""
Main Backend Manager - Apartment Billing Management System
"""

import sqlite3
from typing import List, Dict, Optional
from .repositories import (
    DatabaseConnection, TenantRepository, UnitRepository, 
    BillingRepository, TenantBillingRepository, PaymentRepository
)
from .services import BillingService
from .auth import AuthenticationService
from .models import Tenant, Unit, Billing, TenantBilling, Payment
from .enums import BillingStatus, PaymentMethod


class ApartmentBillingBackend:
    """Main backend manager class"""
    
    def __init__(self, db_path: str = 'apartment_billing.db'):
        self.db = DatabaseConnection(db_path)
        self.db_path = db_path
        self.tenant_repo = TenantRepository(self.db)
        self.unit_repo = UnitRepository(self.db)
        self.billing_repo = BillingRepository(self.db)
        self.tenant_billing_repo = TenantBillingRepository(self.db)
        self.payment_repo = PaymentRepository(self.db)
        self.billing_service = BillingService(self.db)
        
        # Initialize authentication and database
        self.auth_service = AuthenticationService(db_path)
    
    # ==================== TENANT OPERATIONS ====================
    def create_tenant(self, full_name: str, contact_number: str, email: str,
                     unit_number: str, rent_amount: float, move_in_date: str,
                     notes: str = "", address: str = "") -> int:
        """Create a new tenant"""
        tenant = Tenant(
            full_name=full_name,
            contact_number=contact_number,
            email=email,
            unit_number=unit_number,
            rent_amount=rent_amount,
            move_in_date=move_in_date,
            address=address
        )
        return self.tenant_repo.create(tenant)
    
    def get_tenant(self, tenant_id: int) -> Optional[Dict]:
        """Get tenant by ID"""
        tenant = self.tenant_repo.read(tenant_id)
        return tenant.to_dict() if tenant else None
    
    def get_all_tenants(self) -> List[Dict]:
        """Get all tenants"""
        tenants = self.tenant_repo.read_all()
        return [t.to_dict() for t in tenants]
    
    def get_tenants_by_unit(self, unit_number: str) -> List[Dict]:
        """Get all active tenants in a specific unit"""
        tenants = self.tenant_repo.read_all()
        return [t.to_dict() for t in tenants 
                if t._unit_number == unit_number and t._active]
    
    def update_tenant(self, tenant_id: int, **kwargs) -> bool:
        """Update tenant details, including unit change with occupancy tracking"""
        tenant = self.tenant_repo.read(tenant_id)
        if not tenant:
            raise ValueError(f"Tenant {tenant_id} not found")
        
        # Check if unit is being changed
        old_unit_number = tenant._unit_number
        new_unit_number = kwargs.get('unit_number', old_unit_number)
        unit_changed = old_unit_number != new_unit_number
        
        allowed_fields = {
            'full_name': 'full_name',
            'email': 'email',
            'contact_number': '_contact_number',
            'address': '_address',
            'move_in_date': '_move_in_date',
            'notes': '_notes',
            'rent_amount': 'rent_amount',
            'unit_number': '_unit_number'  # Add unit_number to allowed fields
        }
        
        for key, value in kwargs.items():
            if key in allowed_fields:
                prop_name = allowed_fields[key]
                try:
                    if prop_name in ['full_name', 'email', 'rent_amount', 'address', '_unit_number']:
                        setattr(tenant, prop_name, value)
                    else:
                        setattr(tenant, prop_name, value)
                except Exception as e:
                    print(f"Warning: Could not set {key}: {e}")
        
        # Update tenant in repository
        update_result = self.tenant_repo.update(tenant_id, tenant)
        
        # If unit was changed, record occupancy history
        if unit_changed:
            try:
                pass
                
                # Update old unit occupancy if it has no more tenants
                old_unit_tenants = self.get_unit_tenants(old_unit_number)
                if len(old_unit_tenants) == 0:
                    old_unit = self.unit_repo.read_by_unit_number(old_unit_number)
                    if old_unit:
                        old_unit._occupied = False
                        self.unit_repo.update(old_unit.id, old_unit)
                
                # Update new unit occupancy
                new_unit = self.unit_repo.read_by_unit_number(new_unit_number)
                if new_unit:
                    new_unit._occupied = True
                    self.unit_repo.update(new_unit.id, new_unit)
                
                print(f"✓ Tenant {tenant_id} moved from Unit {old_unit_number} to Unit {new_unit_number}")
            except Exception as e:
                print(f"Warning: Could not record occupancy history for unit change: {str(e)}")
        
        return update_result
    
    def delete_tenant(self, tenant_id: int) -> bool:
        """Delete tenant and update unit occupancy, record occupancy history"""
        tenant = self.tenant_repo.read(tenant_id)
        if tenant:
            # Get tenant info before deleting for occupancy history
            unit_number = tenant._unit_number
            move_in_date = tenant._move_in_date
            
            # No occupancy history recording
            
            # Delete the tenant from the repository
            self.tenant_repo.delete(tenant_id)
            
            # Update unit's occupied status if no more tenants in the unit
            unit_tenants = self.get_unit_tenants(unit_number)
            if len(unit_tenants) == 0:
                # Unit is now vacant, update it
                unit = self.unit_repo.read_by_unit_number(unit_number)
                if unit:
                    updated_unit = Unit(
                        unit_number=unit.unit_number,
                        default_rent=unit.default_rent,
                        occupied=False,
                        max_tenants=unit.max_tenants,
                        id=unit.id
                    )
                    self.unit_repo.update(unit.id, updated_unit)
                    print(f"✓ Unit {unit_number} is now vacant")
            
            return True
        return False
    


    # ==================== UNIT OPERATIONS ====================
    def create_unit(self, unit_number: str, default_rent: float, max_tenants: int = 2) -> int:
        """Create a new unit"""
        existing = self.unit_repo.read_by_unit_number(unit_number)
        if existing:
            raise ValueError(f"Unit {unit_number} already exists")
        
        from .models import Unit
        unit = Unit(
            unit_number=unit_number,
            default_rent=default_rent,
            max_tenants=max_tenants
        )
        return self.unit_repo.create(unit)
    
    def get_unit(self, unit_id: int) -> Optional[Dict]:
        """Get unit by ID"""
        unit = self.unit_repo.read(unit_id)
        if not unit:
            return None

        unit_dict = unit.to_dict()
        tenants_in_unit = self.get_unit_tenants(unit.unit_number)
        current_count = len(tenants_in_unit)
        unit_dict['current_tenant_count'] = current_count
        unit_dict['available_slots'] = max(0, unit.max_tenants - current_count)
        unit_dict['occupied'] = current_count > 0
        unit_dict['is_full'] = current_count >= unit.max_tenants
        return unit_dict
    
    def get_all_units(self) -> List[Dict]:
        """Get all units with current occupancy count"""
        units = self.unit_repo.read_all()
        units_list = []
        
        for u in units:
            unit_dict = u.to_dict()
            # Get actual tenant count from database
            tenants_in_unit = self.get_unit_tenants(u.unit_number)
            current_count = len(tenants_in_unit)
            unit_dict['current_tenant_count'] = current_count
            unit_dict['available_slots'] = max(0, u.max_tenants - current_count)
            # Derive occupancy flags from actual tenant count to avoid stale internal flags
            unit_dict['occupied'] = current_count > 0
            unit_dict['is_full'] = current_count >= u.max_tenants
            units_list.append(unit_dict)
        
        return units_list
    
    def update_unit(self, unit_id: int, **kwargs) -> bool:
        """Update unit details with validation"""
        unit = self.unit_repo.read(unit_id)
        if not unit:
            raise ValueError(f"Unit {unit_id} not found")
        
        # Get current tenant count
        all_tenants = self.tenant_repo.read_all()
        current_tenant_count = sum(1 for t in all_tenants if t._unit_number == unit._unit_number)
        
        # Validate max_tenants if being changed
        if 'max_tenants' in kwargs:
            new_max_tenants = kwargs['max_tenants']
            if new_max_tenants < current_tenant_count:
                raise ValueError(
                    f"Cannot set max tenants to {new_max_tenants}. "
                    f"Unit {unit._unit_number} currently has {current_tenant_count} tenant(s). "
                    f"Must be at least {current_tenant_count}."
                )
        
        # Update properties using setters (for validation)
        for key, value in kwargs.items():
            if hasattr(unit, key) and isinstance(getattr(type(unit), key, None), property):
                setattr(unit, key, value)
            elif hasattr(unit, f'_{key}'):
                setattr(unit, f'_{key}', value)
        
        return self.unit_repo.update(unit_id, unit)
    
    def delete_unit(self, unit_id: int) -> bool:
        """Delete unit"""
        return self.unit_repo.delete(unit_id)
    
    # ==================== BILLING OPERATIONS ====================
    def create_billing(self, unit_number: str, billing_month: str, due_date: str,
                      total_water: float = 0, total_electricity: float = 0,
                      total_wifi: float = 0, rent: float = 0) -> int:
        """Create a new billing
        
        If due_date is in the past, the billing and all tenant_billings 
        will be marked as OVERDUE for immediate collection.
        """
        from .models import Billing
        from datetime import datetime
        
        billing = Billing(
            unit_number=unit_number,
            billing_month=billing_month,
            due_date=due_date,
            total_water=total_water,
            total_electricity=total_electricity,
            total_wifi=total_wifi,
            rent=rent
        )
        billing_id = self.billing_repo.create(billing)
        
        # Check if billing is overdue (due_date is in the past)
        try:
            # Try to parse as YYYY-MM-DD first, then fall back to YYYY-MM
            try:
                due_date_obj = datetime.strptime(due_date, "%Y-%m-%d").date()
            except ValueError:
                # If it's in YYYY-MM format, use the last day of that month
                due_date_obj = datetime.strptime(due_date + "-01", "%Y-%m-%d").date()
                # Move to last day of month
                from datetime import timedelta
                due_date_obj = (due_date_obj.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            
            today = datetime.now().date()
            
            if due_date_obj < today:
                print(f"⚠️ OVERDUE BILLING CREATED: Unit {unit_number}, Month: {billing_month}, Due: {due_date}")
        except Exception as e:
            print(f"Warning: Could not check overdue status: {str(e)}")
        
        return billing_id
    
    def get_billing(self, billing_id: int) -> Optional[Dict]:
        """Get billing by ID"""
        billing = self.billing_repo.read(billing_id)
        return billing.to_dict() if billing else None
    
    def get_all_billings(self) -> List[Dict]:
        """Get all billings"""
        billings = self.billing_repo.read_all()
        return [b.to_dict() for b in billings]
    
    def update_billing(self, billing_id: int, **kwargs) -> bool:
        """Update billing details"""
        billing = self.billing_repo.read(billing_id)
        if not billing:
            raise ValueError(f"Billing {billing_id} not found")
        
        for key, value in kwargs.items():
            if hasattr(billing, f'_{key}'):
                setattr(billing, key, value)
        
        return self.billing_repo.update(billing_id, billing)
    
    def delete_billing(self, billing_id: int) -> bool:
        """Delete billing"""
        return self.billing_repo.delete(billing_id)
    
    # ==================== TENANT BILLING OPERATIONS ====================
    def create_tenant_billing(self, tenant_id: int, billing_id: int,
                             water_share: float = 0, electricity_share: float = 0,
                             wifi_share: float = 0, rent_share: float = 0,
                             manual_adjustment: float = 0) -> int:
        """Create tenant billing record
        
        Automatically marks billing as OVERDUE if due_date is in the past.
        """
        from .models import TenantBilling
        from datetime import datetime
        
        # Get the billing to check if it's overdue
        billing = self.billing_repo.read(billing_id)
        if not billing:
            raise ValueError(f"Billing {billing_id} not found")
        
        # Determine status based on due_date
        status = BillingStatus.PENDING.value
        try:
            # Try to parse as YYYY-MM-DD first, then fall back to YYYY-MM
            try:
                due_date_obj = datetime.strptime(billing._due_date, "%Y-%m-%d").date()
            except ValueError:
                # If it's in YYYY-MM format, use the last day of that month
                due_date_obj = datetime.strptime(billing._due_date + "-01", "%Y-%m-%d").date()
                # Move to last day of month
                from datetime import timedelta
                due_date_obj = (due_date_obj.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
            
            today = datetime.now().date()
            
            if due_date_obj < today:
                status = BillingStatus.OVERDUE.value
                print(f"🔴 TENANT BILLING MARKED AS OVERDUE - Tenant {tenant_id}, Billing {billing_id}")
        except Exception as e:
            print(f"Warning: Could not check billing due date: {str(e)}")
        
        # Create tenant_billing with appropriate status
        tenant_billing = TenantBilling(
            tenant_id=tenant_id,
            billing_id=billing_id,
            water_share=water_share,
            electricity_share=electricity_share,
            wifi_share=wifi_share,
            rent_share=rent_share,
            manual_adjustment=manual_adjustment,
            status=status
        )
        return self.tenant_billing_repo.create(tenant_billing)
    
    def get_tenant_billing(self, tenant_billing_id: int) -> Optional[Dict]:
        """Get tenant billing by ID"""
        tenant_billing = self.tenant_billing_repo.read(tenant_billing_id)
        return tenant_billing.to_dict() if tenant_billing else None
    
    def get_all_tenant_billings(self) -> List[Dict]:
        """Get all tenant billings"""
        tenant_billings = self.tenant_billing_repo.read_all()
        # Exclude tenant billings that have a negative total amount — these should not be shown as bills
        result = []
        for tb in tenant_billings:
            tb_dict = tb.to_dict()
            # If total_amount is negative, skip it
            try:
                if tb_dict.get('total_amount', 0) < 0:
                    continue
            except Exception:
                # If for some reason total_amount is missing or invalid, include the record to avoid hiding data
                pass
            result.append(tb_dict)

        return result

    def get_negative_tenant_billings(self) -> List[Dict]:
        """Return tenant billings that have negative total amounts (credits/adjustments)."""
        tenant_billings = self.tenant_billing_repo.read_all()
        negatives = []
        for tb in tenant_billings:
            tb_dict = tb.to_dict()
            try:
                if tb_dict.get('total_amount', 0) < 0:
                    negatives.append(tb_dict)
            except Exception:
                # If missing/invalid, skip
                continue
        return negatives
    
    def update_tenant_billing(self, tenant_billing_id: int, **kwargs) -> bool:
        """Update tenant billing details"""
        tenant_billing = self.tenant_billing_repo.read(tenant_billing_id)
        if not tenant_billing:
            raise ValueError(f"Tenant billing {tenant_billing_id} not found")
        
        for key, value in kwargs.items():
            if hasattr(tenant_billing, f'_{key}'):
                setattr(tenant_billing, key, value)
        
        return self.tenant_billing_repo.update(tenant_billing_id, tenant_billing)
    
    def delete_tenant_billing(self, tenant_billing_id: int) -> bool:
        """Delete tenant billing"""
        return self.tenant_billing_repo.delete(tenant_billing_id)
    
    def get_tenant_billing_with_payments(self, tenant_billing_id: int) -> Optional[Dict]:
        """Get tenant billing with payment history"""
        billing = self.tenant_billing_repo.read(tenant_billing_id)
        if not billing:
            return None
        
        billing_dict = billing.to_dict()
        
        # Get payments for this billing
        payments = self.payment_repo.read_all()
        billing_payments = [p.to_dict() for p in payments if p._tenant_billing_id == tenant_billing_id]
        
        billing_dict['payments'] = billing_payments
        billing_dict['total_paid'] = sum(p['amount_paid'] for p in billing_payments)
        # Never expose a negative balance; if overpaid, show zero balance
        billing_dict['balance'] = max(0, billing_dict['total_amount'] - billing_dict['total_paid'])
        
        return billing_dict
    
    # ==================== PAYMENT OPERATIONS ====================
    def record_payment(self, tenant_id: int, billing_month: str, amount_paid: float,
                      payment_method: str = PaymentMethod.CASH.value,
                      payment_date: Optional[str] = None, tenant_billing_id: Optional[int] = None,
                      apply_advance: bool = True) -> int:
        """
        Record a payment with advanced logic:
        1. Handle negative amounts (credits) - add to advance payment
        2. Apply advanced payment credits to billing first
        3. Use remaining amount as payment
        4. Update/delete billing when paid
        5. Mark overdue billings as updated
        """
        from .models import Payment
        
        # Handle negative amounts (credits)
        if amount_paid < 0:
            # Negative amount means a credit/refund for the tenant
            # Add this to their advance payment balance
            advance_payment = Payment(
                tenant_id=tenant_id,
                billing_month='ADVANCE',
                amount_paid=abs(amount_paid),  # Convert to positive for advance
                payment_method=payment_method,
                payment_date=payment_date,
                tenant_billing_id=None
            )
            payment_id = self.payment_repo.create(advance_payment)
            print(f"✓ Credit recorded: Tenant {tenant_id}, Amount ₱{abs(amount_paid):.2f} added to advance payment")
            return payment_id
        
        # Allow zero amount when advance application is requested for a specific tenant_billing
        if amount_paid == 0 and not (apply_advance and tenant_billing_id):
            raise ValueError("Payment amount cannot be zero")
        
        # Get current advanced payment balance
        advance_balance = self.get_tenant_advanced_payment(tenant_id)
        actual_payment = amount_paid
        advance_applied_amount = 0
        
        # Handle billing updates if tenant_billing_id is provided
        if tenant_billing_id:
            try:
                billing = self.tenant_billing_repo.read(tenant_billing_id)
                if billing:
                    total_due = billing.total_amount
                    
                    # First, try to apply advance payment to reduce the billing if requested
                    if apply_advance and advance_balance > 0:
                        # Apply advance toward the remaining due (function will compute remaining and deduct advance rows)
                        try:
                            result = self.apply_advanced_payment_to_billing(tenant_id, tenant_billing_id)
                            advance_applied_amount = float(result or 0)
                            applied_payment_id = None
                        except Exception:
                            advance_applied_amount = 0
                            applied_payment_id = None

                        # Update billing amount due
                        total_due = max(0, total_due - advance_applied_amount)
                        # Subtract the applied advance from the cash amount the tenant will be charged
                        cash_to_record = max(0, float(amount_paid) - advance_applied_amount)
                    else:
                        cash_to_record = float(amount_paid)

                    # Check if billing is fully paid (including advance credit)
                    if cash_to_record >= total_due:
                        # Mark as paid (but keep the billing record for history)
                        billing._status = BillingStatus.PAID.value
                        self.tenant_billing_repo.update(tenant_billing_id, billing)
                        print(f"✓ Billing marked as paid: Tenant {tenant_id}, Month {billing_month}, Cash ₱{cash_to_record:.2f} (Advance: ₱{advance_applied_amount:.2f})")
                    else:
                        # Partial payment
                        billing._status = BillingStatus.PARTIAL.value
                        self.tenant_billing_repo.update(tenant_billing_id, billing)
                        print(f"✓ Billing updated to partial: Tenant {tenant_id}, Cash ₱{cash_to_record:.2f}/{total_due + advance_applied_amount:.2f} (Advance: ₱{advance_applied_amount:.2f})")
            except Exception as e:
                print(f"Warning: Could not update billing status: {str(e)}")
        
        # Record payments:
        # - If advance applied and user paid cash too: create two payments (ADVANCE + cash)
        # - If advance applied and user paid zero cash: create only the ADVANCE payment
        # - Otherwise create a single payment for the cash amount
        payment_id = None
        try:
            if advance_applied_amount > 0 and cash_to_record > 0:
                # Create advance-applied payment record (applied to this billing)
                adv_payment = Payment(
                    tenant_id=tenant_id,
                    billing_month=billing_month,
                    amount_paid=float(advance_applied_amount),
                    payment_method=PaymentMethod.ADVANCE.value,
                    payment_date=payment_date,
                    tenant_billing_id=tenant_billing_id
                )
                adv_id = self.payment_repo.create(adv_payment)

                # Create the cash/other payment record only for the remaining cash amount
                cash_payment = Payment(
                    tenant_id=tenant_id,
                    billing_month=billing_month,
                    amount_paid=float(cash_to_record),
                    payment_method=payment_method,
                    payment_date=payment_date,
                    tenant_billing_id=tenant_billing_id
                )
                cash_id = self.payment_repo.create(cash_payment)
                payment_id = cash_id

            elif advance_applied_amount > 0 and cash_to_record == 0:
                # Only record the advance-applied payment
                adv_payment = Payment(
                    tenant_id=tenant_id,
                    billing_month=billing_month,
                    amount_paid=float(advance_applied_amount),
                    payment_method=PaymentMethod.ADVANCE.value,
                    payment_date=payment_date,
                    tenant_billing_id=tenant_billing_id
                )
                payment_id = self.payment_repo.create(adv_payment)

            else:
                # No advance applied, record single payment for entered amount
                payment = Payment(
                    tenant_id=tenant_id,
                    billing_month=billing_month,
                    amount_paid=float(amount_paid),
                    payment_method=payment_method,
                    payment_date=payment_date,
                    tenant_billing_id=tenant_billing_id
                )
                payment_id = self.payment_repo.create(payment)
        except Exception:
            # If creation failed, return None (advance was already deducted from advance rows)
            payment_id = None
        
        # Update all overdue billings for this tenant if they have been paid
        try:
            self._update_overdue_billings(tenant_id)
        except Exception as e:
            print(f"Warning: Could not update overdue billings: {str(e)}")
        
        return payment_id
    
    def _update_overdue_billings(self, tenant_id: int) -> None:
        """
        Update status of all overdue billings for a tenant.
        Mark pending overdue billings that have payments as partial/paid.
        Clears overdue status when paid.
        """
        import sqlite3
        from datetime import datetime
        
        try:
            conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get all tenant billings for this tenant (pending, overdue, or partial)
            cursor.execute("""
                SELECT tb.id, tb.tenant_id, b.billing_month, b.due_date, 
                       tb.total_amount, tb.status, COALESCE(SUM(p.amount_paid), 0) as total_paid
                FROM tenant_billings tb
                JOIN billings b ON tb.billing_id = b.id
                LEFT JOIN payments p ON tb.tenant_id = p.tenant_id AND b.billing_month = p.billing_month
                WHERE tb.tenant_id = ? AND tb.status IN ('unpaid', 'overdue', 'partially_paid')
                GROUP BY tb.id
            """, (tenant_id,))
            
            tenant_billings = cursor.fetchall()
            
            updated_count = 0
            for row in tenant_billings:
                billing_id = row['id']
                total_amount = row['total_amount']
                total_paid = row['total_paid']
                old_status = row['status']
                
                if total_paid >= total_amount:
                    # Fully paid - mark as paid (do not delete, keep for history)
                    cursor.execute("UPDATE tenant_billings SET status = 'paid' WHERE id = ?", (billing_id,))
                    print(f"✓ Overdue billing CLEARED: {row['billing_month']} - Status changed from '{old_status}' to PAID")
                    updated_count += 1
                elif total_paid > 0:
                    # Partially paid - update status
                    cursor.execute("UPDATE tenant_billings SET status = 'partially_paid' WHERE id = ?", (billing_id,))
                    print(f"✓ Overdue billing UPDATED: {row['billing_month']} - Status changed from '{old_status}' to PARTIALLY_PAID (Paid: ₱{total_paid:.2f} / Total: ₱{total_amount:.2f})")
                    updated_count += 1
            
            conn.commit()
            conn.close()
            
            if updated_count > 0:
                print(f"📊 TOTAL UPDATES: {updated_count} overdue billing(s) processed for Tenant {tenant_id}")
        except Exception as e:
            print(f"Warning: Error updating overdue billings: {str(e)}")
    
    def handle_advanced_payment(self, tenant_id: int, amount: float, payment_method: str = "advance") -> bool:
        """
        Create an advanced payment record that can be applied to future billings.
        Returns True if successful.
        """
        try:
            # Store advanced payment as a special payment record with amount as credit
            from .models import Payment
            
            payment = Payment(
                tenant_id=tenant_id,
                billing_month="ADVANCE",
                amount_paid=amount,
                payment_method=payment_method,
                payment_date=None,
                tenant_billing_id=None
            )
            payment_id = self.payment_repo.create(payment)
            print(f"✓ Advanced payment recorded: ₱{amount:.2f} for Tenant {tenant_id}")
            return True
        except Exception as e:
            print(f"✗ Error recording advanced payment: {str(e)}")
            return False
    
    def apply_advanced_payment_to_billing(self, tenant_id: int, tenant_billing_id: int) -> float:
        """
        Apply advanced payments to a billing.
        Returns the amount of advanced payment applied (float).
        """
        try:
            import sqlite3
            
            conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            cursor = conn.cursor()
            
            # Get total advanced payment balance
            cursor.execute("""
                SELECT COALESCE(SUM(amount_paid), 0) as advance_balance
                FROM payments
                WHERE tenant_id = ? AND billing_month = 'ADVANCE'
            """, (tenant_id,))
            
            result = cursor.fetchone()
            advance_balance = result[0] if result else 0
            
            # Get billing amount and existing payments for this tenant_billing
            cursor.execute("""
                SELECT tb.total_amount, b.billing_month
                FROM tenant_billings tb
                JOIN billings b ON tb.billing_id = b.id
                WHERE tb.id = ?
            """, (tenant_billing_id,))

            billing_row = cursor.fetchone()
            if not billing_row:
                conn.close()
                return 0

            billing_amount = billing_row[0]
            billing_month = billing_row[1]

            # Sum existing payments already applied to this tenant_billing
            cursor.execute("""
                SELECT COALESCE(SUM(amount_paid), 0) FROM payments
                WHERE tenant_billing_id = ?
            """, (tenant_billing_id,))
            existing_paid_row = cursor.fetchone()
            existing_paid = existing_paid_row[0] if existing_paid_row else 0

            remaining_due = max(0, billing_amount - existing_paid)

            # Calculate how much to apply from advance (don't exceed remaining due)
            amount_to_apply = min(advance_balance, remaining_due)
            applied_payment_id = None
            
            if amount_to_apply > 0:
                # Deduct from advanced payment records (apply across advance rows until covered)
                remaining = amount_to_apply
                cursor.execute("""
                    SELECT id, amount_paid FROM payments
                    WHERE tenant_id = ? AND billing_month = 'ADVANCE' AND amount_paid > 0
                    ORDER BY id
                """, (tenant_id,))
                adv_rows = cursor.fetchall()
                for adv in adv_rows:
                    adv_id = adv[0]
                    adv_amt = adv[1]
                    to_deduct = min(adv_amt, remaining)
                    if to_deduct > 0:
                        cursor.execute("""
                            UPDATE payments SET amount_paid = amount_paid - ? WHERE id = ?
                        """, (to_deduct, adv_id))
                        remaining -= to_deduct
                    if remaining <= 0:
                        break
                
                # Mark billing as paid if fully covered (do not delete, keep for history)
                if amount_to_apply >= billing_amount:
                    cursor.execute("""
                        UPDATE tenant_billings SET status = 'paid' WHERE id = ?
                    """, (tenant_billing_id,))
                    print(f"✓ Billing marked paid using advanced payment: ₱{amount_to_apply:.2f}")
                else:
                    cursor.execute("""
                        UPDATE tenant_billings SET status = 'partial' WHERE id = ?
                    """, (tenant_billing_id,))
                    print(f"✓ Partial billing paid using advanced payment: ₱{amount_to_apply:.2f}")

                # Commit all updates (deductions from advance rows and billing status)
                conn.commit()
                conn.close()
                return amount_to_apply
        except Exception as e:
            print(f"Warning: Error applying advanced payment: {str(e)}")
            return 0
    
    def get_tenant_advanced_payment(self, tenant_id: int) -> float:
        """Get remaining advanced payment balance for a tenant"""
        try:
            import sqlite3
            
            conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
            conn.execute("PRAGMA journal_mode=WAL")
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT COALESCE(SUM(amount_paid), 0) as balance
                FROM payments
                WHERE tenant_id = ? AND billing_month = 'ADVANCE'
            """, (tenant_id,))
            
            result = cursor.fetchone()
            balance = result[0] if result else 0
            
            conn.close()
            return balance
        except Exception as e:
            print(f"Warning: Error getting advanced payment: {str(e)}")
            return 0
    
    def get_payment(self, payment_id: int) -> Optional[Dict]:
        """Get payment by ID"""
        payment = self.payment_repo.read(payment_id)
        return payment.to_dict() if payment else None
    
    def get_all_payments(self) -> List[Dict]:
        """Get all payments"""
        payments = self.payment_repo.read_all()
        return [p.to_dict() for p in payments]
    
    def update_payment(self, payment_id: int, **kwargs) -> bool:
        """Update payment details"""
        payment = self.payment_repo.read(payment_id)
        if not payment:
            raise ValueError(f"Payment {payment_id} not found")
        
        for key, value in kwargs.items():
            if hasattr(payment, f'_{key}'):
                setattr(payment, key, value)
        
        return self.payment_repo.update(payment_id, payment)
    
    def delete_payment(self, payment_id: int) -> bool:
        """Delete payment"""
        return self.payment_repo.delete(payment_id)
    
    # ==================== ANALYTICS & REPORTS ====================
    def get_tenant_outstanding_balance(self, tenant_id: int, billing_month: str) -> float:
        """Get outstanding balance for a tenant"""
        return self.billing_service.get_outstanding_balance(tenant_id, billing_month)
    
    def get_collection_summary(self, billing_month: str) -> Dict:
        """Get collection summary for a billing month"""
        query = """
            SELECT 
                COUNT(DISTINCT tb.id) as total_billings,
                SUM(tb.total_amount) as total_amount_due,
                SUM(COALESCE(p.amount_paid, 0)) as amount_collected
            FROM tenant_billings tb
            JOIN billings b ON tb.billing_id = b.id
            LEFT JOIN (
                SELECT tenant_id, billing_month, SUM(amount_paid) as amount_paid
                FROM payments
                GROUP BY tenant_id, billing_month
            ) p ON tb.tenant_id = p.tenant_id AND b.billing_month = p.billing_month
            WHERE b.billing_month = ?
        """
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        cursor = conn.cursor()
        try:
            cursor.execute(query, (billing_month,))
            result = cursor.fetchone()
        finally:
            conn.close()
        
        if not result or result[1] is None:
            return {
                'total_billings': 0,
                'total_amount_due': 0.0,
                'amount_collected': 0.0,
                'amount_outstanding': 0.0,
                'collection_rate': 0.0
            }
        
        total_due = result[1]
        collected = result[2] or 0.0
        outstanding = total_due - collected
        collection_rate = (collected / total_due * 100) if total_due > 0 else 0
        
        return {
            'total_billings': result[0],
            'total_amount_due': total_due,
            'amount_collected': collected,
            'amount_outstanding': outstanding,
            'collection_rate': round(collection_rate, 2)
        }
    
    
    def get_all_units_with_occupancy(self) -> List[Dict]:
        """Get all units with occupancy details"""
        all_units = self.get_all_units()
        result = []
        
        for unit in all_units:
            tenants = self.get_unit_tenants(unit['unit_number'])
            max_tenants = unit.get('max_tenants', 2)
            current_count = len(tenants)
            
            available_slots = max(0, max_tenants - current_count)
            occupancy_percentage = (current_count / max_tenants * 100) if max_tenants > 0 else 0
            
            result.append({
                'unit_number': unit['unit_number'],
                'default_rent': unit['default_rent'],
                'max_tenants': max_tenants,
                'current_tenant_count': current_count,
                'available_slots': available_slots,
                'is_vacant': current_count == 0,
                'is_full': current_count >= max_tenants,
                'occupancy_percentage': occupancy_percentage
            })
        
        return result
    
    def get_occupancy_report(self) -> Dict:
        """Get comprehensive occupancy report"""
        all_units = self.get_all_units()
        all_tenants = self.get_all_tenants()
        units_with_occupancy = self.get_all_units_with_occupancy()
        
        total_units = len(all_units)
        
        # Calculate fully occupied, partially occupied, and vacant units
        fully_occupied_units = sum(1 for u in units_with_occupancy if u['current_tenant_count'] == u['max_tenants'] and u['current_tenant_count'] > 0)
        partially_occupied_units = sum(1 for u in units_with_occupancy if 0 < u['current_tenant_count'] < u['max_tenants'])
        vacant_units = sum(1 for u in units_with_occupancy if u['current_tenant_count'] == 0)
        
        total_capacity = sum(u.get('max_tenants', 2) for u in all_units)
        total_occupied = len(all_tenants)
        total_available = total_capacity - total_occupied
        
        return {
            'total_units': total_units,
            'occupied_units': fully_occupied_units,  # Now represents fully occupied units
            'vacant_units': vacant_units,
            'occupancy_rate': (fully_occupied_units / total_units * 100) if total_units > 0 else 0,  # Percentage of fully occupied units
            'total_capacity': total_capacity,
            'total_occupied': total_occupied,
            'total_available_slots': total_available,
            'capacity_usage': (total_occupied / total_capacity * 100) if total_capacity > 0 else 0,
            'units': units_with_occupancy
        }
    
    def get_pending_billings(self, tenant_id: int) -> List[Dict]:
        """Get all pending billings for a tenant"""
        query = """
            SELECT 
                tb.id,
                tb.billing_id,
                b.billing_month,
                b.due_date,
                (tb.water_share + tb.electricity_share + tb.wifi_share + tb.rent_share) as total_amount,
                'unpaid' as status,
                ((tb.water_share + tb.electricity_share + tb.wifi_share + tb.rent_share) - COALESCE(SUM(p.amount_paid), 0)) as amount_due
            FROM tenant_billings tb
            JOIN billings b ON tb.billing_id = b.id
            LEFT JOIN payments p ON tb.tenant_id = p.tenant_id AND b.billing_month = p.billing_month
            WHERE tb.tenant_id = ?
            GROUP BY tb.id, tb.billing_id, b.billing_month, b.due_date
            ORDER BY b.billing_month DESC
        """
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(query, (tenant_id,))
            results = cursor.fetchall()
        finally:
            conn.close()
        
        pending = []
        for row in results:
            # Compute amount_due fallback
            amount_due = row['amount_due'] if row['amount_due'] is not None else row['total_amount']
            # Skip billings that have no positive amount due (i.e., fully paid or credit/negative)
            try:
                if float(amount_due) <= 0:
                    continue
            except Exception:
                # If parsing fails, include the record to avoid hiding data
                pass

            pending.append({
                'tenant_billing_id': row['id'],
                'billing_id': row['billing_id'],
                'billing_month': row['billing_month'],
                'due_date': row['due_date'],
                'total_amount': row['total_amount'],
                'status': row['status'],
                'amount_due': amount_due
            })
        
        return pending
    
    def get_tenant_payment_history(self, tenant_id: int) -> List[Dict]:
        """Get payment history for a tenant"""
        query = """
            SELECT p.id, p.tenant_id, p.billing_month, p.amount_paid, 
                   p.payment_method, p.payment_date, t.full_name
            FROM payments p
            JOIN tenants t ON p.tenant_id = t.id
            WHERE p.tenant_id = ?
            ORDER BY p.payment_date DESC
        """
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(query, (tenant_id,))
            results = cursor.fetchall()
        finally:
            conn.close()
        
        return [
            {
                'id': row['id'],
                'tenant_id': row['tenant_id'],
                'billing_month': row['billing_month'],
                'amount_paid': row['amount_paid'],
                'payment_method': row['payment_method'],
                'payment_date': row['payment_date'],
                'tenant_name': row['full_name']
            }
            for row in results
        ]
    
    def get_unit_tenants(self, unit_number: str) -> List[Dict]:
        """Get all tenants in a unit"""
        tenants = self.tenant_repo.read_all()
        active_tenants = [t for t in tenants if t._unit_number == unit_number and t.active]
        return [t.to_dict() for t in active_tenants]
    
    def get_unit_occupancy_details(self, unit_number: str) -> Dict:
        """Get detailed occupancy information for a unit"""
        unit = self.unit_repo.read_by_unit_number(unit_number)
        tenants = self.get_unit_tenants(unit_number)
        
        if not unit:
            raise ValueError(f"Unit {unit_number} not found")
        
        unit_dict = unit.to_dict()
        max_tenants = unit_dict.get('max_tenants', 2)
        
        return {
            'unit_number': unit_dict['unit_number'],
            'default_rent': unit_dict['default_rent'],
            'max_tenants': max_tenants,
            'current_tenant_count': len(tenants),
            'available_slots': max(0, max_tenants - len(tenants)),
            'is_vacant': len(tenants) == 0,
            'is_full': len(tenants) >= max_tenants,
            'tenants': tenants,
            'occupancy_percentage': (len(tenants) / max_tenants * 100) if max_tenants > 0 else 0
        }
    
    
    def get_dashboard_stats(self) -> Dict:
        """Get dashboard statistics"""
        all_tenants = self.get_all_tenants()
        all_units = self.get_all_units()
        all_billings = self.get_all_billings()
        all_payments = self.get_all_payments()
        
        # Calculate total collected this month
        from datetime import datetime
        current_month = datetime.now().strftime("%Y-%m")
        # Only count positive payments (exclude negative credits) in top-level collected totals
        month_payments = [p for p in all_payments if p.get('billing_month', '').startswith(current_month) and p.get('amount_paid', 0) > 0]
        total_collected = sum(p.get('amount_paid', 0) for p in month_payments)
        
        return {
            'total_tenants': len([t for t in all_tenants if t.get('active', True)]),
            'total_units': len(all_units),
            'occupied_units': sum(1 for u in all_units if u.get('occupied', False)),
            'vacant_units': sum(1 for u in all_units if not u.get('occupied', False)),
            'total_billings': len(all_billings),
            # Count only positive payments for dashboard metrics (exclude negative credits)
            'total_payments': len([p for p in all_payments if p.get('amount_paid', 0) > 0]),
            'total_collected': total_collected,
            'total_units_capacity': sum(u.get('max_tenants', 2) for u in all_units)
        }
    
    def get_tenant_statistics(self) -> Dict:
        """Get detailed tenant statistics"""
        all_tenants = self.get_all_tenants()
        active_tenants = [t for t in all_tenants if t.get('active', True)]
        inactive_tenants = [t for t in all_tenants if not t.get('active', True)]
        
        total_rent = sum(t.get('rent_amount', 0) for t in active_tenants)
        average_rent = (total_rent / len(active_tenants)) if active_tenants else 0
        
        return {
            'total_tenants': len(all_tenants),
            'active_tenants': len(active_tenants),
            'inactive_tenants': len(inactive_tenants),
            'total_rent_per_month': total_rent,
            'average_rent_per_tenant': round(average_rent, 2),
            'tenants': all_tenants
        }
