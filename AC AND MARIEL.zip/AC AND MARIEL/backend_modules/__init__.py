"""
Backend modules for Apartment Billing Management System
Modular architecture with separation of concerns
"""

from .enums import BillingStatus, PaymentMethod
from .auth import AuthenticationService
from .models import Entity, Tenant, Unit, Billing, TenantBilling, Payment
from .repositories import (
    DatabaseConnection,
    Repository,
    TenantRepository,
    UnitRepository,
    BillingRepository,
    TenantBillingRepository,
    PaymentRepository
)
from .services import BillingService
from .backend import ApartmentBillingBackend

__all__ = [
    # Enums
    'BillingStatus',
    'PaymentMethod',
    
    # Authentication
    'AuthenticationService',
    
    # Models
    'Entity',
    'Tenant',
    'Unit',
    'Billing',
    'TenantBilling',
    'Payment',
    
    # Repositories
    'DatabaseConnection',
    'Repository',
    'TenantRepository',
    'UnitRepository',
    'BillingRepository',
    'TenantBillingRepository',
    'PaymentRepository',
    
    # Services
    'BillingService',
    
    # Main Backend
    'ApartmentBillingBackend',
]
