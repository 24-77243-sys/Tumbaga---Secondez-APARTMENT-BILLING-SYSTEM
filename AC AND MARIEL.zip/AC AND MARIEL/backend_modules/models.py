"""
Entity models for Apartment Billing Management System
Based on original backend.py classes with full OOP principles
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from datetime import datetime
from .enums import BillingStatus, PaymentMethod


class Entity(ABC):
    """Abstract base class for all entities"""
    
    def __init__(self, id: Optional[int] = None):
        self.id = id
    
    @abstractmethod
    def to_dict(self) -> Dict:
        """Convert entity to dictionary"""
        pass
    
    @abstractmethod
    def validate(self) -> bool:
        """Validate entity data"""
        pass


class Tenant(Entity):
    """Tenant model with encapsulation"""
    
    def __init__(self, full_name: str, contact_number: str, email: str, 
                 unit_number: str, rent_amount: float, move_in_date: str,
                 notes: str = "", address: str = "", active: bool = True, id: Optional[int] = None):
        super().__init__(id)
        self._full_name = full_name
        self._contact_number = contact_number
        self._email = email
        self._unit_number = unit_number
        self._rent_amount = rent_amount
        self._move_in_date = move_in_date
        self._notes = notes
        self._address = address
        self._active = active
    
    # Properties with getters and setters (encapsulation)
    @property
    def full_name(self) -> str:
        return self._full_name
    
    @full_name.setter
    def full_name(self, value: str):
        if not value or len(value) < 2:
            raise ValueError("Full name must be at least 2 characters")
        self._full_name = value
    
    @property
    def email(self) -> str:
        return self._email
    
    @email.setter
    def email(self, value: str):
        if "@" not in value:
            raise ValueError("Invalid email format")
        self._email = value
    
    @property
    def rent_amount(self) -> float:
        return self._rent_amount
    
    @rent_amount.setter
    def rent_amount(self, value: float):
        if value < 0:
            raise ValueError("Rent amount cannot be negative")
        self._rent_amount = value
    
    @property
    def active(self) -> bool:
        return self._active
    
    @active.setter
    def active(self, value: bool):
        self._active = value
    
    @property
    def address(self) -> str:
        return self._address

    @address.setter
    def address(self, value: str):
        # address may be optional but sanitize length
        if value is not None and len(value) > 500:
            raise ValueError("Address too long")
        self._address = value
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'full_name': self._full_name,
            'contact_number': self._contact_number,
            'email': self._email,
            'address': self._address,
            'unit_number': self._unit_number,
            'rent_amount': self._rent_amount,
            'move_in_date': self._move_in_date,
            'notes': self._notes,
            'active': self._active
        }
    
    def validate(self) -> bool:
        return (
            self._full_name and len(self._full_name) >= 2 and
            self._email and "@" in self._email and
            self._rent_amount >= 0 and
            self._unit_number
        )


class Unit(Entity):
    """Unit model with tenant relationship tracking"""
    
    def __init__(self, unit_number: str, default_rent: float, 
                 occupied: bool = False, max_tenants: int = 2, id: Optional[int] = None):
        super().__init__(id)
        self._unit_number = unit_number
        self._default_rent = default_rent
        self._occupied = occupied
        self._max_tenants = max_tenants
        self._current_tenants = []
    
    @property
    def unit_number(self) -> str:
        return self._unit_number

    @unit_number.setter
    def unit_number(self, value: str):
        if not value or len(value.strip()) == 0:
            raise ValueError("Unit number cannot be empty")
        self._unit_number = value
    @property
    def total_water(self) -> float:
        return self._total_water

    @total_water.setter
    def total_water(self, value: float):
        if value < 0:
            raise ValueError("Water cost cannot be negative")
        self._total_water = value

    @property
    def total_electricity(self) -> float:
        return self._total_electricity

    @total_electricity.setter
    def total_electricity(self, value: float):
        if value < 0:
            raise ValueError("Electricity cost cannot be negative")
        self._total_electricity = value

    @property
    def total_wifi(self) -> float:
        return self._total_wifi

    @total_wifi.setter
    def total_wifi(self, value: float):
        if value < 0:
            raise ValueError("WiFi cost cannot be negative")
        self._total_wifi = value

    @property
    def rent(self) -> float:
        return self._rent

    @rent.setter
    def rent(self, value: float):
        if value < 0:
            raise ValueError("Rent cannot be negative")
        self._rent = value
    
    
    @property
    def default_rent(self) -> float:
        return self._default_rent
    
    @default_rent.setter
    def default_rent(self, value: float):
        if value < 0:
            raise ValueError("Default rent cannot be negative")
        self._default_rent = value
    
    @property
    def occupied(self) -> bool:
        return self._occupied
    
    @occupied.setter
    def occupied(self, value: bool):
        self._occupied = value
    
    @property
    def max_tenants(self) -> int:
        return self._max_tenants
    
    @max_tenants.setter
    def max_tenants(self, value: int):
        if value < 1:
            raise ValueError("Maximum tenants must be at least 1")
        self._max_tenants = value
    
    @property
    def current_tenants(self) -> List[int]:
        return self._current_tenants
    
    @property
    def tenant_count(self) -> int:
        return len(self._current_tenants)
    
    @property
    def available_slots(self) -> int:
        return max(0, self._max_tenants - self.tenant_count)
    
    @property
    def is_vacant(self) -> bool:
        return self.tenant_count == 0
    
    @property
    def is_full(self) -> bool:
        return self.tenant_count >= self._max_tenants
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'unit_number': self._unit_number,
            'default_rent': self._default_rent,
            'occupied': self._occupied,
            'max_tenants': self._max_tenants,
            'current_tenants': self._current_tenants,
            'tenant_count': self.tenant_count,
            'available_slots': self.available_slots,
            'is_vacant': self.is_vacant,
            'is_full': self.is_full
        }
    
    def validate(self) -> bool:
        return self._unit_number and self._default_rent >= 0 and self._max_tenants >= 1


class Billing(Entity):
    """Billing model for unit-level billing"""
    
    def __init__(self, unit_number: str, billing_month: str, due_date: str,
                 total_water: float = 0, total_electricity: float = 0,
                 total_wifi: float = 0, rent: float = 0, id: Optional[int] = None):
        super().__init__(id)
        self._unit_number = unit_number
        self._billing_month = billing_month
        self._due_date = due_date
        self._total_water = total_water
        self._total_electricity = total_electricity
        self._total_wifi = total_wifi
        self._rent = rent
    
    @property
    def unit_number(self) -> str:
        return self._unit_number
    
    @property
    def total_utilities(self) -> float:
        """Calculate total utilities"""
        return self._total_water + self._total_electricity + self._total_wifi
    @property
    def total_water(self) -> float:
        return self._total_water

    @total_water.setter
    def total_water(self, value: float):
        if value < 0:
            raise ValueError("Water cost cannot be negative")
        self._total_water = value

    @property
    def total_electricity(self) -> float:
        return self._total_electricity

    @total_electricity.setter
    def total_electricity(self, value: float):
        if value < 0:
            raise ValueError("Electricity cost cannot be negative")
        self._total_electricity = value

    @property
    def total_wifi(self) -> float:
        return self._total_wifi

    @total_wifi.setter
    def total_wifi(self, value: float):
        if value < 0:
            raise ValueError("WiFi cost cannot be negative")
        self._total_wifi = value

    @property
    def rent(self) -> float:
        return self._rent

    @rent.setter
    def rent(self, value: float):
        if value < 0:
            raise ValueError("Rent cannot be negative")
        self._rent = value
    
    
    @property
    def total_amount(self) -> float:
        """Calculate total billing amount"""
        return self.total_utilities + self._rent
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'unit_number': self._unit_number,
            'billing_month': self._billing_month,
            'due_date': self._due_date,
            'total_water': self._total_water,
            'total_electricity': self._total_electricity,
            'total_wifi': self._total_wifi,
            'rent': self._rent,
            'total_utilities': self.total_utilities,
            'total_amount': self.total_amount
        }
    
    def validate(self) -> bool:
        return (
            self._unit_number and
            self._billing_month and
            self._due_date and
            all(v >= 0 for v in [self._total_water, self._total_electricity, 
                                 self._total_wifi, self._rent])
        )


class TenantBilling(Entity):
    """Tenant-level billing model (shares of unit billing)"""
    
    def __init__(self, tenant_id: int, billing_id: int, water_share: float = 0,
                 electricity_share: float = 0, wifi_share: float = 0,
                 rent_share: float = 0, manual_adjustment: float = 0,
                 status: str = BillingStatus.UNPAID.value, id: Optional[int] = None):
        super().__init__(id)
        self._tenant_id = tenant_id
        self._billing_id = billing_id
        self._water_share = water_share
        self._electricity_share = electricity_share
        self._wifi_share = wifi_share
        self._rent_share = rent_share
        self._manual_adjustment = manual_adjustment
        self._status = status
    
    @property
    def total_amount(self) -> float:
        """Calculate tenant's total billing amount"""
        utilities = self._water_share + self._electricity_share + self._wifi_share
        return utilities + self._rent_share + self._manual_adjustment
    
    @property
    def status(self) -> str:
        return self._status
    
    @status.setter
    def status(self, value: str):
        if value not in [s.value for s in BillingStatus]:
            raise ValueError(f"Invalid status. Must be one of {[s.value for s in BillingStatus]}")
        self._status = value
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'tenant_id': self._tenant_id,
            'billing_id': self._billing_id,
            'water_share': self._water_share,
            'electricity_share': self._electricity_share,
            'wifi_share': self._wifi_share,
            'rent_share': self._rent_share,
            'manual_adjustment': self._manual_adjustment,
            'total_amount': self.total_amount,
            'status': self._status
        }
    
    def validate(self) -> bool:
        return (
            self._tenant_id > 0 and
            self._billing_id > 0 and
            all(v >= -1000 for v in [self._water_share, self._electricity_share,
                                     self._wifi_share, self._rent_share, self._manual_adjustment])
        )


class Payment(Entity):
    """Payment model"""
    
    def __init__(self, tenant_id: int, billing_month: str, amount_paid: float,
                 payment_method: str = PaymentMethod.CASH.value, 
                 payment_date: Optional[str] = None, tenant_billing_id: Optional[int] = None,
                 id: Optional[int] = None):
        super().__init__(id)
        self._tenant_id = tenant_id
        self._billing_month = billing_month
        self._amount_paid = amount_paid
        self._payment_method = payment_method
        self._payment_date = payment_date or datetime.now().strftime("%Y-%m-%d")
        self._tenant_billing_id = tenant_billing_id
    
    @property
    def amount_paid(self) -> float:
        return self._amount_paid
    
    @amount_paid.setter
    def amount_paid(self, value: float):
        if value < 0:
            raise ValueError("Payment amount cannot be negative")
        self._amount_paid = value
    
    @property
    def tenant_billing_id(self) -> Optional[int]:
        return self._tenant_billing_id
    
    @tenant_billing_id.setter
    def tenant_billing_id(self, value: Optional[int]):
        self._tenant_billing_id = value
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'tenant_id': self._tenant_id,
            'billing_month': self._billing_month,
            'amount_paid': self._amount_paid,
            'payment_method': self._payment_method,
            'payment_date': self._payment_date,
            'tenant_billing_id': self._tenant_billing_id
        }
    
    def validate(self) -> bool:
        return (
            self._tenant_id > 0 and
            self._billing_month and
            self._amount_paid >= 0 and
            self._payment_method in [m.value for m in PaymentMethod]
        )
