"""
Service layer for business logic
Based on original backend.py BillingService
"""

import sqlite3
from typing import List, Dict, Optional
from .repositories import (
    DatabaseConnection, TenantRepository, BillingRepository,
    TenantBillingRepository, PaymentRepository
)
from .models import TenantBilling
from .enums import BillingStatus


class BillingService:
    """Service for billing business logic"""
    
    def __init__(self, db_connection: DatabaseConnection):
        self.db_connection = db_connection
        self.db_path = db_connection.db_path
        self.tenant_repo = TenantRepository(db_connection)
        self.billing_repo = BillingRepository(db_connection)
        self.tenant_billing_repo = TenantBillingRepository(db_connection)
        self.payment_repo = PaymentRepository(db_connection)
    
    def get_outstanding_balance(self, tenant_id: int, billing_month: str) -> float:
        """Calculate outstanding balance for tenant"""
        query = """
            SELECT SUM(tb.water_share + tb.electricity_share + tb.wifi_share + tb.rent_share + tb.manual_adjustment) 
            as total_amount FROM tenant_billings tb
            JOIN billings b ON tb.billing_id = b.id
            WHERE tb.tenant_id = ? AND b.billing_month = ?
        """
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            cursor = conn.cursor()
            cursor.execute(query, (tenant_id, billing_month))
            result = cursor.fetchone()
        finally:
            conn.close()
        
        if not result or result[0] is None:
            return 0.0
        
        total_billing = result[0]
        payments = self.payment_repo.read_by_tenant_and_month(tenant_id, billing_month)
        paid_amount = sum(p.amount_paid for p in payments)
        
        return max(0, total_billing - paid_amount)
    
    def get_overdue_billings(self) -> List[Dict]:
        """Get all overdue billings"""
        query = """
            SELECT tb.id, t.id, t.full_name, t.unit_number, b.billing_month, b.due_date,
                   (tb.water_share + tb.electricity_share + tb.wifi_share + tb.rent_share + tb.manual_adjustment) as total_amount
            FROM tenant_billings tb
            JOIN billings b ON tb.billing_id = b.id
            JOIN tenants t ON tb.tenant_id = t.id
            WHERE b.due_date < date('now') AND tb.status != 'paid'
            ORDER BY b.due_date ASC
        """
        conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        try:
            cursor = conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
        finally:
            conn.close()
        
        return [
            {
                'id': r[0],
                'tenant_id': r[1],
                'tenant_name': r[2],
                'unit_number': r[3],
                'billing_month': r[4],
                'due_date': r[5],
                'amount': r[6]
            }
            for r in results
        ]
    
    def update_billing_status(self, tenant_billing_id: int, status: str) -> bool:
        """Update billing status"""
        tenant_billing = self.tenant_billing_repo.read(tenant_billing_id)
        if not tenant_billing:
            raise ValueError("Tenant billing not found")
        
        tenant_billing.status = status
        return self.tenant_billing_repo.update(tenant_billing_id, tenant_billing)
