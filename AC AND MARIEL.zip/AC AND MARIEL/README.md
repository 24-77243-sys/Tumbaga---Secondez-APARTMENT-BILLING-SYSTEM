# Apartment Billing Management System - Installation Guide

## Overview
This is a Python-based desktop application for managing apartment billings, tenant information, payments, and reports. The application uses CustomTkinter for the GUI and SQLite for data storage.

---

## System Requirements

- **Python**: 3.8 or higher
- **OS**: Windows, macOS, or Linux
- **RAM**: Minimum 2GB
- **Disk Space**: ~500MB for installation and database

---

## Installation Steps

### Step 1: Install Python

Download and install Python from https://www.python.org/downloads/

**During installation, make sure to check:**
- ✓ "Add Python to PATH"
- ✓ "Install pip"

Verify installation:
```bash
python --version
pip --version
```

### Step 2: Navigate to Project Directory

```bash
cd "C:\Users\ACER\OneDrive\Desktop\AC AND MARIEL"
```


### Step 3: Upgrade pip

```bash
python -m pip install --upgrade pip
```

### Step 4: Install Required Libraries

All required libraries are listed below. Install them with:

```bash
pip install -r requirements.txt
```

**Or install individually:**

```bash
pip install customtkinter==5.2.0
pip install pillow==10.1.0
```

---

## Required Libraries

### Core Dependencies

| **customtkinter** | 5.2.0+ | Modern GUI framework for desktop interface |
| **pillow** | 10.1.0+ | Image processing (for icons and graphics) |
| **sqlite3** | Built-in | Database management (included with Python) |

### Standard Library (Included with Python)

- `datetime` - Date and time handling
- `hashlib` - Password hashing
- `json` - Data serialization
- `threading` - Asynchronous operations
- `typing` - Type hints
- `abc` - Abstract base classes

---

## Detailed Installation Instructions

### Windows PowerShell

```powershell
# 1. Navigate to project


# 2. Create virtual environment
python -m venv .venv1

# 3. Activate virtual environment
.\.venv1\Scripts\Activate.ps1

# If you get a security error, run this first:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# 4. Upgrade pip
python -m pip install --upgrade pip

# 5. Install dependencies
pip install customtkinter==5.2.0
pip install pillow==10.1.0

# 6. Verify installation
pip list

# 7. Run the application
python main.py
```

### macOS/Linux (Bash/Zsh)

SYSTEM NAME: APARTMENT BILLING SYSTEM

Feautures:
-add tenants
-add units
-create billing
-locate the tenants information
-add a tenant inside a unit
- check if the unit has a maximum number of tenants

### Step by step guidelines on hownto use the system.
- Since this is a system to manipulate billings in a unit, it should be used by the administrator of the units.
- Log in to the system by typing the username and password admin
- The dashboard will show with buttons beside. These buttons are dashboard, tenants, units, billings, payments, colection summary, overdue billings, payment history, tenant statistics, unit occupancy and vacant units.
- For the dashboard tab it shows the general overview of the system. How many tenants, active units, total billings and total payments has been made. It also shows the collection summary of the system.
- In the tenants tab it shows the information of the tenants. Their names, Email, address and the unit they are in. The user can also add, delete and update tenant information in this system.
- In Units tab, the admin can see the units infos if they are occupied or not.
- In billing management, the admin can create billings in this tab. It consists of water, electricity, wifi and rent per unit amount.
- In payment management, the admin can add a payment from the tenants. The tenants can also advance their payment.
- Collection Summary consists of the important information in the billing process in the corresponding month.
- Overdue Billings show who is the tenants whose the billing is overdue.
- Payment history shows the history of the tenants who paid their overdue billings.
- Tenant Statistics shows the statistics of all of the tenants who avail in each and every units available in the system. It also shows the total tenants and the total mothly rent (bills excluded)
- Unit Occupancy shows if the unit is over to their maximum capacity and their available slot if not.
- Vacant Units show which Unit is not full.


