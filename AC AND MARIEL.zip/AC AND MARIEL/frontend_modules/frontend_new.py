"""
Apartment Billing Management System - Modern UI
Complete redesign with advanced features and smooth interactions
"""

import customtkinter as ctk
from tkinter import messagebox, ttk
from datetime import datetime, timedelta
from backend_modules import *


# ========================= CONFIGURATION =========================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class Config:
    """Application configuration"""
    # Colors
    PRIMARY_COLOR = "#667EEA"
    SECONDARY_COLOR = "#764BA2"
    ACCENT_COLOR = "#F093FB"
    SUCCESS_COLOR = "#48BB78"
    DANGER_COLOR = "#F56565"
    WARNING_COLOR = "#ED8936"
    INFO_COLOR = "#4299E1"
    
    BG_DARK = "#0F1419"
    BG_DARKER = "#0A0E13"
    BG_CARD = "#1A1F2E"
    BG_HOVER = "#2D3748"
    
    TEXT_PRIMARY = "#FFFFFF"
    TEXT_SECONDARY = "#A0AEC0"
    TEXT_MUTED = "#718096"
    
    BORDER_COLOR = "#2D3748"
    
    # Fonts
    # Fonts (increased for better readability)
    # Base/body font set to 15 as requested; headings scaled proportionally
    FONT_HEADING = ("Segoe UI", 34, "bold")
    FONT_TITLE = ("Segoe UI", 22, "bold")
    FONT_SUBTITLE = ("Segoe UI", 18, "bold")
    FONT_BODY = ("Segoe UI", 15)
    FONT_SMALL = ("Segoe UI", 15)
    FONT_TINY = ("Segoe UI", 13)
    # Standard table column widths (pixels)
    TABLE_COL_WIDTHS = {
        'id': 50,
        'name': 200,
        'email': 180,
        'address': 200,
        'unit': 100,
        'rent': 130,
        'contact': 120,
        'move_in': 100,
        'actions': 90,
        # Payment history columns
        'tenant': 260,
        'month': 140,
        'amount': 140,
        'method': 120,
        'date': 160,
    }


# ========================= MODERN LOGIN PAGE =========================
class ModernLoginUI(ctk.CTk):
    """Modern animated login interface"""
    
    def __init__(self):
        super().__init__()
        self.title("Apartment Billing System")
        # Increased initial window size to better fit larger fonts
        self.geometry("1280x768")
        self.resizable(False, False)
        
        self.auth = AuthenticationService()
        self.backend = None
        
        self._setup_ui()
        self._center_window()
    
    def _center_window(self):
        """Center window on screen"""
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")
    
    def _setup_ui(self):
        """Setup login UI"""
        main_frame = ctk.CTkFrame(self, fg_color=Config.BG_DARK)
        main_frame.pack(fill="both", expand=True)
        
        # Left side - Branding
        left_frame = ctk.CTkFrame(main_frame, fg_color=Config.PRIMARY_COLOR)
        left_frame.pack(side="left", fill="both", expand=True, anchor="nw")
        
        # Gradient overlay effect
        brand_container = ctk.CTkFrame(left_frame, fg_color=Config.PRIMARY_COLOR)
        brand_container.pack(fill="both", expand=True, padx=40, pady=40, anchor="nw")
        
        ctk.CTkLabel(
            brand_container,
            text="🏢",
            font=("Segoe UI", 80),
            text_color=Config.TEXT_PRIMARY
        ).pack(pady=(50, 20))
        
        
        ctk.CTkLabel(
            brand_container,
            text="Apartment Billing System",
            font=("Segoe UI", 32, "bold"),
            text_color=Config.TEXT_PRIMARY
        ).pack(pady=(10, 50))
        
        
        # Right side - Login Form
        right_frame = ctk.CTkFrame(main_frame, fg_color=Config.BG_DARKER)
        right_frame.pack(side="right", fill="both", expand=True)
        
        form_container = ctk.CTkFrame(right_frame, fg_color=Config.BG_DARKER)
        form_container.pack(expand=True, padx=60, pady=60)
        
        ctk.CTkLabel(
            form_container,
            text="Welcome!",
            font=("Segoe UI", 32, "bold"),
            text_color=Config.TEXT_PRIMARY
        ).pack(pady=(0, 5))
        
        ctk.CTkLabel(
            form_container,
            text="Sign in to access your dashboard",
            font=("Segoe UI", 12),
            text_color=Config.TEXT_SECONDARY
        ).pack(pady=(0, 40))
        
        # Username
        ctk.CTkLabel(
            form_container,
            text="👤 Username",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        self.username_var = ctk.StringVar()
        username_entry = ctk.CTkEntry(
            form_container,
            textvariable=self.username_var,
            placeholder_text="Enter your username",
            height=45,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.BORDER_COLOR,
            border_width=2,
            corner_radius=8
        )
        username_entry.pack(fill="x", pady=(0, 20))
        username_entry.bind("<Return>", lambda e: self._login())
        
        # Password
        ctk.CTkLabel(
            form_container,
            text="🔐 Password",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        self.password_var = ctk.StringVar()
        password_entry = ctk.CTkEntry(
            form_container,
            textvariable=self.password_var,
            placeholder_text="Enter your password",
            height=45,
            font=Config.FONT_SMALL,
            show="•",
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.BORDER_COLOR,
            border_width=2,
            corner_radius=8
        )
        password_entry.pack(fill="x", pady=(0, 25))
        password_entry.bind("<Return>", lambda e: self._login())
        
        
        # Login button
        login_btn = ctk.CTkButton(
            form_container,
            text="🚀 Sign In",
            height=50,
            font=("Segoe UI", 14, "bold"),
            fg_color=Config.PRIMARY_COLOR,
            hover_color=Config.SECONDARY_COLOR,
            text_color=Config.TEXT_PRIMARY,
            corner_radius=8,
            command=self._login
        )
        login_btn.pack(fill="x", pady=(0, 20))
    
    def _login(self):
        """Handle login"""
        username = self.username_var.get().strip()
        password = self.password_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter username and password")
            return
        
        if self.auth.verify_login(username, password):
            user = self.auth.get_user(username)
            self.backend = ApartmentBillingBackend()
            self.withdraw()
            # Use the inline MainDashboard implementation
            MainDashboard(self, user, self.backend)
        else:
            messagebox.showerror("Login Failed", "Invalid credentials")
            self.password_var.set("")


# ========================= MAIN DASHBOARD =========================
class MainDashboard(ctk.CTkToplevel):
    """Main dashboard with modern design"""
    
    def __init__(self, parent, user, backend):
        super().__init__(parent)
        self.title("Apartment Billing System - Dashboard")
        self.geometry("1920x1080")
        self.state("zoomed")
        self.resizable(True, True)
        
        self.user = user
        self.backend = backend
        self.parent = parent
        self.current_view = None
        
        self._setup_dashboard()
        self._center_window()
    
    def _center_window(self):
        """Center window on screen"""
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (w // 2)
        y = (self.winfo_screenheight() // 2) - (h // 2)
        self.geometry(f"{w}x{h}+{x}+{y}")
    
    def _setup_dashboard(self):
        """Setup dashboard layout"""
        main_container = ctk.CTkFrame(self, fg_color=Config.BG_DARK)
        main_container.pack(fill="both", expand=True)
        
        # Top Navigation Bar
        self._create_navbar(main_container)
        
        # Main content area
        content_container = ctk.CTkFrame(main_container, fg_color=Config.BG_DARK)
        content_container.pack(fill="both", expand=True)
        
        # Sidebar
        self._create_sidebar(content_container)
        
        # Content area
        self.content_frame = ctk.CTkScrollableFrame(
            content_container,
            fg_color=Config.BG_DARK,
            corner_radius=0
        )
        self.content_frame.pack(side="right", fill="both", expand=True, padx=20, pady=20)
        
        self.show_dashboard()
    
    def _create_navbar(self, parent):
        """Create top navigation bar"""
        navbar = ctk.CTkFrame(parent, fg_color=Config.BG_CARD, height=70, corner_radius=0)
        navbar.pack(fill="x", side="top")
        navbar.pack_propagate(False)
        
        # Left section
        left_section = ctk.CTkFrame(navbar, fg_color=Config.BG_CARD)
        left_section.pack(side="left", padx=20, pady=15)
        
        ctk.CTkLabel(
            left_section,
            text="📊 Dashboard",
            font=("Segoe UI", 22, "bold"),
            text_color=Config.TEXT_PRIMARY
        ).pack()
        
        # Right section
        right_section = ctk.CTkFrame(navbar, fg_color=Config.BG_CARD)
        right_section.pack(side="right", padx=20, pady=15)
        
        ctk.CTkLabel(
            right_section,
            text=f"👤 {self.user.get('full_name', 'Admin')}",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_SECONDARY
        ).pack(side="left", padx=20)
        
        ctk.CTkButton(
            right_section,
            text="🚪 Logout",
            font=Config.FONT_SMALL,
            fg_color=Config.DANGER_COLOR,
            hover_color="#C53030",
            text_color=Config.TEXT_PRIMARY,
            width=100,
            height=35,
            corner_radius=6,
            command=self._logout
        ).pack(side="left", padx=5)
    
    def _create_sidebar(self, parent):
        """Create sidebar navigation"""
        sidebar = ctk.CTkFrame(parent, fg_color=Config.BG_CARD, width=250, corner_radius=0)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        
        # Menu sections
        self._add_menu_section(sidebar, "MAIN", [
            ("📊 Dashboard", self.show_dashboard),
            ("👥 Tenants", self.show_tenants),
            ("🏠 Units", self.show_units),
            ("📋 Billings", self.show_billings),
            ("💳 Payments", self.show_payments),
            ("⏱️ Advance", self._add_advanced_payment_dialog),
        ])
        
        self._add_menu_section(sidebar, "REPORTS", [

            ("💰 Payment History", self.show_payment_history),
            ("👥 Tenant Statistics", self.show_tenant_stats),
        ])
        
        self._add_menu_section(sidebar, "OCCUPANCY", [
            ("🏢 Unit Occupancy", self.show_occupancy),
        ])
    
    def _add_menu_section(self, parent, title, items):
        """Add menu section to sidebar"""
        ctk.CTkLabel(
            parent,
            text=title,
            font=("Segoe UI", 10, "bold"),
            text_color=Config.TEXT_MUTED
        ).pack(anchor="w", padx=15, pady=(20, 10))
        
        for label, command in items:
            btn = ctk.CTkButton(
                parent,
                text=label,
                command=command,
                font=Config.FONT_SMALL,
                fg_color="transparent",
                text_color=Config.TEXT_PRIMARY,
                hover_color=Config.BG_HOVER,
                corner_radius=6,
                height=40,
                anchor="w",
                border_spacing=12
            )
            btn.pack(fill="x", padx=10, pady=3)
    
    def _clear_content(self):
        """Clear content area"""
        for widget in self.content_frame.winfo_children():
            widget.destroy()
    
    def _create_stat_card(self, parent, title, value, icon, color, command=None):
        """Create stat card with optional click command"""
        card = ctk.CTkFrame(parent, fg_color=color, corner_radius=12)
        card.pack(side="left", fill="both", expand=True, padx=10, pady=0)
        
        if command:
            card.configure(cursor="hand2")
            card.bind("<Button-1>", lambda e: command())
        
        content = ctk.CTkFrame(card, fg_color=color)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        if command:
            content.bind("<Button-1>", lambda e: command())
        
        icon_label = ctk.CTkLabel(
            content,
            text=icon,
            font=("Segoe UI", 40),
            text_color=Config.TEXT_PRIMARY
        )
        icon_label.pack()
        
        if command:
            icon_label.bind("<Button-1>", lambda e: command())
        
        title_label = ctk.CTkLabel(
            content,
            text=title,
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        )
        title_label.pack(pady=(10, 5))
        
        if command:
            title_label.bind("<Button-1>", lambda e: command())
        
        value_label = ctk.CTkLabel(
            content,
            text=str(value),
            font=("Segoe UI", 28, "bold"),
            text_color=Config.TEXT_PRIMARY
        )
        value_label.pack()
        
        if command:
            value_label.bind("<Button-1>", lambda e: command())
    
    def show_dashboard(self):
        """Show main dashboard with live updates and billing stats"""
        self._clear_content()
        
        # Title with refresh button
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="📊 Dashboard Overview",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        ctk.CTkButton(
            title_frame,
            text="🔄 Refresh",
            command=self.show_dashboard,
            font=Config.FONT_SMALL,
            fg_color=Config.SECONDARY_COLOR,
            hover_color="#5A3A7A",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        # Get all data from system
        tenants = self.backend.get_all_tenants()
        units = self.backend.get_all_units()
        billings = self.backend.get_all_tenant_billings()
        payments = self.backend.get_all_payments()
        
        # Calculate comprehensive statistics
        active_units = [u for u in units if u['occupied']]
        vacant_units = [u for u in units if not u['occupied']]

        pending_billings = [b for b in billings if b['status'] == 'pending']
        paid_billings = [b for b in billings if b['status'] == 'paid']
        
        # Count paid/unpaid tenants (by tenant billing status)
        paid_tenants_count = len([b for b in billings if b['status'] == 'paid'])
        unpaid_tenants_count = len([b for b in billings if b['status'] in ('pending', 'partially_paid', 'overdue')])

        # Compute unit-based billing statistics using unit billings, tenant billings and payments
        unit_billings = self.backend.get_all_billings()
        tenant_level_billings = billings  # from get_all_tenant_billings()
        payments = payments or []

        # Map billing_id -> tenant billing records
        tb_by_billing = {}
        tb_id_to_billing = {}
        for tb in tenant_level_billings:
            bid = tb.get('billing_id')
            tb_by_billing.setdefault(bid, []).append(tb)
            tb_id_to_billing[tb.get('id')] = bid

        # Map tenant_billing_id -> sum of payments applied
        payments_by_tb = {}
        for p in payments:
            try:
                tbid = p.get('tenant_billing_id')
                amt = float(p.get('amount_paid', 0))
                if tbid:
                    payments_by_tb[tbid] = payments_by_tb.get(tbid, 0) + amt
            except Exception:
                continue

        # Aggregate per-unit stats
        unpaid_unit_billings = []
        total_amount_due = 0.0
        total_billings_amount = 0.0
        total_paid_amount = 0.0
        paid_units_count = 0
        for ub in unit_billings:
            bid = ub.get('id')
            unit_no = ub.get('unit_number', 'Unknown')
            unit_amount = float(ub.get('total_amount', 0) or 0)
            # number of tenants in this unit
            try:
                unit_tenants = self.backend.get_unit_tenants(ub.get('unit_number'))
                num_tenants = len(unit_tenants)
            except Exception:
                num_tenants = len([t for t in tenants if t.get('unit_number') == ub.get('unit_number')])

            # tenant-level billings for this unit billing
            tbs = tb_by_billing.get(bid, [])

            # If tenant-level billings exist, compute per-tenant amount (use average to be safe)
            # otherwise derive per-tenant amount from unit_amount / num_tenants
            per_tenant_amount = 0.0
            if tbs:
                try:
                    totals = [float(tb.get('total_amount', 0) or 0) for tb in tbs]
                    per_tenant_amount = sum(totals) / max(1, len(totals))
                except Exception:
                    per_tenant_amount = unit_amount / max(1, num_tenants)
            else:
                per_tenant_amount = unit_amount / max(1, num_tenants)

            # Total expected for the unit based on per-tenant billing * number of tenants
            unit_total_billing = per_tenant_amount * max(1, num_tenants)
            total_billings_amount += unit_total_billing

            # sum payments applied to these tenant billings
            collected = 0.0
            for tb in tbs:
                collected += payments_by_tb.get(tb.get('id'), 0)

            # amount to collect based on per-tenant * num_tenants minus collected payments
            amount_to_collect = max(0.0, unit_total_billing - collected)
            unpaid = amount_to_collect
            total_amount_due += amount_to_collect
            total_paid_amount += min(collected, unit_total_billing)

            # status determination - check both calculated amount and actual tenant billing statuses
            statuses = [tb.get('status') for tb in tbs if tb.get('status')]
            if any(s == 'overdue' for s in statuses):
                status = 'overdue'
            elif amount_to_collect == 0 and all(s == 'paid' for s in statuses if s):
                # Only mark as paid if both: (1) amount collected, and (2) all tenant billings are paid
                status = 'paid'
            elif any(s in ('pending', 'partially_paid', 'overdue') for s in statuses):
                # If any tenant billing is unpaid, mark unit as unpaid
                status = 'unpaid'
            elif amount_to_collect > 0:
                status = 'unpaid'
            else:
                status = 'paid'

            if unpaid > 0:
                unpaid_unit_billings.append({'unit_number': unit_no, 'total_amount': unpaid, 'status': status})
            if status == 'paid':
                paid_units_count += 1
        
        # Stats with clickable cards
        stats_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        stats_frame.pack(fill="x", pady=20)
        
        self._create_stat_card(stats_frame, "Total Tenants", len(tenants), "👥", Config.PRIMARY_COLOR, command=self.show_tenants)
        self._create_stat_card(stats_frame, "Active Units", len(active_units), "🏠", Config.SUCCESS_COLOR, command=self.show_units)
        self._create_stat_card(stats_frame, "Unpaid Billings", len(pending_billings), "📋", Config.WARNING_COLOR, command=self.show_unpaid_tenants)
        self._create_stat_card(stats_frame, "Total Payments", len(payments), "💳", Config.ACCENT_COLOR, command=self.show_payments)
        
        # Billing Statistics
        ctk.CTkLabel(
            self.content_frame,
            text="📊 Billing Statistics",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        billing_stats_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
        billing_stats_frame.pack(fill="x", pady=15)

        billing_stats = [
            (f"🔴 Unpaid Tenants: {unpaid_tenants_count} | Amount: ₱{total_amount_due:,.2f}", Config.WARNING_COLOR, self.show_unpaid_tenants),
            (f"✅ Paid Tenants: {paid_tenants_count} | Amount: ₱{total_paid_amount:,.2f}", Config.SUCCESS_COLOR, self.show_billings),
        ]
        
        for text, color, command in billing_stats:
            item = ctk.CTkFrame(billing_stats_frame, fg_color=Config.BG_DARK, corner_radius=8)
            item.pack(fill="x", padx=15, pady=8)
            item.configure(cursor="hand2")
            
            label = ctk.CTkLabel(
                item,
                text=text,
                font=Config.FONT_BODY,
                text_color=color
            )
            label.pack(padx=15, pady=12, anchor="w")
            
            item.bind("<Button-1>", lambda e, cmd=command: cmd())
            label.bind("<Button-1>", lambda e, cmd=command: cmd())

        # Per-unit unpaid breakdown
        try:
            # Group unpaid_unit_billings by unit_number
            unit_unpaid_map = {}
            for ub in unpaid_unit_billings:
                unit_no = ub.get('unit_number') or ub.get('unit') or 'Unknown'
                unit_unpaid_map.setdefault(unit_no, 0)
                unit_unpaid_map[unit_no] += ub.get('total_amount', 0)

            if unit_unpaid_map:
                breakdown_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=8)
                breakdown_frame.pack(fill="x", padx=20, pady=(10, 15))
                ctk.CTkLabel(breakdown_frame, text="Per-Unit Unpaid:", font=Config.FONT_BODY, text_color=Config.TEXT_PRIMARY).pack(anchor="w", padx=10, pady=(8, 4))
                for unit_no, amt in sorted(unit_unpaid_map.items()):
                    ctk.CTkLabel(breakdown_frame, text=f"Unit {unit_no}: ₱{amt:,.2f}", font=Config.FONT_SMALL, text_color=Config.TEXT_SECONDARY).pack(anchor="w", padx=18, pady=2)
        except Exception:
            pass
        
        # Unit Statistics
        ctk.CTkLabel(
            self.content_frame,
            text="🏢 Unit Statistics",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        unit_stats_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
        unit_stats_frame.pack(fill="x", pady=15)
        
        unit_stats = [
            (f"Total Units: {len(units)}", Config.PRIMARY_COLOR, self.show_units),
            (f"Occupied: {len(active_units)} units", Config.SUCCESS_COLOR, self.show_units),
            (f"Vacant: {len(vacant_units)} units", Config.INFO_COLOR, self.show_units),
        ]
        
        for text, color, command in unit_stats:
            item = ctk.CTkFrame(unit_stats_frame, fg_color=Config.BG_DARK, corner_radius=8)
            item.pack(fill="x", padx=15, pady=8)
            item.configure(cursor="hand2")
            
            label = ctk.CTkLabel(
                item,
                text=text,
                font=Config.FONT_BODY,
                text_color=color
            )
            label.pack(padx=15, pady=12, anchor="w")
            
            item.bind("<Button-1>", lambda e, cmd=command: cmd())
            label.bind("<Button-1>", lambda e, cmd=command: cmd())
        
        # Recent Activities
        ctk.CTkLabel(
            self.content_frame,
            text="⚡ Recent Activities",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        recent = payments[-5:] if payments else []
        if recent:
            for payment in reversed(recent):
                try:
                    tenant = self.backend.get_tenant(payment['tenant_id'])
                    tenant_name = tenant['full_name'] if tenant else f"Tenant {payment['tenant_id']}"
                    unit_number = tenant.get('unit_number', 'N/A') if tenant else 'N/A'
                except:
                    tenant_name = f"Tenant {payment['tenant_id']}"
                    unit_number = 'N/A'
                
                
                activity = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=8)
                activity.pack(fill="x", pady=5)
                activity.configure(cursor="hand2")
                
                label = ctk.CTkLabel(
                    activity,
                    text=f"💳 ₱{payment['amount_paid']:,.2f} from {tenant_name} (Unit {unit_number}, {payment['billing_month']})",
                    font=Config.FONT_SMALL,
                    text_color=Config.SUCCESS_COLOR
                )
                label.pack(padx=15, pady=12, anchor="w")
                
                activity.bind("<Button-1>", lambda e: self.show_payments())
                label.bind("<Button-1>", lambda e: self.show_payments())
        else:
            ctk.CTkLabel(
                self.content_frame,
                text="No recent activities",
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=10)
    
    def show_tenants(self):
        """Show tenants view with aligned table"""
        self._clear_content()
        
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(
            title_frame,
            text="👥 Tenant Management",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        ctk.CTkButton(
            title_frame,
            text="➕ Add Tenant",
            command=self._add_tenant_dialog,
            font=Config.FONT_SMALL,
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        tenants = self.backend.get_all_tenants()
        
        if not tenants:
            ctk.CTkLabel(
                self.content_frame,
                text="No tenants found",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        # Table with fixed column widths
        table_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        table_frame.pack(fill="both", expand=True, pady=0)
        
        # Column width configuration (centralized in Config.TABLE_COL_WIDTHS)
        col_widths = Config.TABLE_COL_WIDTHS.copy()
        
        # Table header
        header = ctk.CTkFrame(table_frame, fg_color=Config.PRIMARY_COLOR, corner_radius=8)
        header.pack(fill="x", pady=(0, 2))
        
        headers = [
            ('ID', 'id'),
            ('Name', 'name'),
            ('Email', 'email'),
            ('Address', 'address'),
            ('Unit', 'unit'),
            ('Rent', 'rent'),
            ('Contact', 'contact'),
            ('Move-In', 'move_in'),
            ('Actions', 'actions')
        ]
        
        for label_text, col_key in headers:
            ctk.CTkLabel(
                header,
                text=label_text,
                font=("Segoe UI", 10, "bold"),
                text_color=Config.TEXT_PRIMARY,
                width=col_widths.get(col_key, 120)
            ).pack(side="left", padx=4, pady=6, anchor="w")
        
        # Table rows
        for i, tenant in enumerate(tenants):
            row_bg = Config.BG_CARD if i % 2 == 0 else Config.BG_DARKER
            row = ctk.CTkFrame(table_frame, fg_color=row_bg, corner_radius=6, height=40)
            row.pack(fill="x", pady=1)
            row.pack_propagate(False)
            
            # ID
            id_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['id'])
            id_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            id_frame.pack_propagate(False)
            ctk.CTkLabel(
                id_frame, 
                text=str(tenant['id']), 
                text_color=Config.TEXT_PRIMARY, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="center")
            
            # Name
            name_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['name'])
            name_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            name_frame.pack_propagate(False)
            ctk.CTkLabel(
                name_frame, 
                text=tenant['full_name'][:20], 
                text_color=Config.TEXT_PRIMARY, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="w")
            
            # Email
            email_display = tenant['email'][:25] + ('...' if len(tenant['email']) > 25 else '')
            email_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['email'])
            email_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            email_frame.pack_propagate(False)
            ctk.CTkLabel(
                email_frame, 
                text=email_display, 
                text_color=Config.TEXT_SECONDARY, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="w")
            
            # Address
            address = str(tenant.get('address', '') or '')[:20]
            address_display = address + ('...' if len(str(tenant.get('address', '') or '')) > 20 else '')
            address_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['address'])
            address_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            address_frame.pack_propagate(False)
            ctk.CTkLabel(
                address_frame, 
                text=address_display, 
                text_color=Config.TEXT_SECONDARY, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="w")
            
            # Unit
            unit_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['unit'])
            unit_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            unit_frame.pack_propagate(False)
            ctk.CTkLabel(
                unit_frame, 
                text=tenant['unit_number'], 
                text_color=Config.ACCENT_COLOR, 
                font=("Segoe UI", 10, "bold")
            ).pack(fill="both", expand=True, anchor="center")
            
            # Rent
            rent_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['rent'])
            rent_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            rent_frame.pack_propagate(False)
            ctk.CTkLabel(
                rent_frame, 
                text=f"₱{tenant['rent_amount']:,.0f}", 
                text_color=Config.SUCCESS_COLOR, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="center")
            
            # Contact
            contact_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['contact'])
            contact_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            contact_frame.pack_propagate(False)
            ctk.CTkLabel(
                contact_frame, 
                text=tenant['contact_number'], 
                text_color=Config.TEXT_SECONDARY, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="w")
            
            # Move-In Date
            date_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['move_in'])
            date_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            date_frame.pack_propagate(False)
            ctk.CTkLabel(
                date_frame, 
                text=tenant['move_in_date'], 
                text_color=Config.TEXT_MUTED, 
                font=Config.FONT_SMALL
            ).pack(fill="both", expand=True, anchor="center")
            
            # Action buttons
            actions_frame = ctk.CTkFrame(row, fg_color=row_bg, width=col_widths['actions'])
            actions_frame.pack(side="left", padx=4, pady=5, fill="both", expand=False)
            actions_frame.pack_propagate(False)
            
            ctk.CTkButton(
                actions_frame,
                text="✏️",
                command=lambda t=tenant: self._update_tenant_dialog(t),
                font=Config.FONT_SMALL,
                fg_color=Config.INFO_COLOR,
                hover_color="#3182CE",
                width=35,
                height=30,
                corner_radius=4
            ).pack(side="left", padx=1)
            
            ctk.CTkButton(
                actions_frame,
                text="🗑️",
                command=lambda tid=tenant['id']: self._delete_tenant(tid),
                font=Config.FONT_SMALL,
                fg_color=Config.DANGER_COLOR,
                hover_color="#E53E3E",
                width=35,
                height=30,
                corner_radius=4
            ).pack(side="left", padx=1)
    
    def _add_tenant_dialog(self):
        """Add tenant dialog with unit selection from database"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Add New Tenant")
        dialog.geometry("500x750")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        
        # Set dark theme for dialog
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        entries = {}
        
        # Full Name
        ctk.CTkLabel(
            content,
            text="Full Name",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['full_name'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['full_name'].pack(fill="x", pady=(0, 10))
        
        # Email
        ctk.CTkLabel(
            content,
            text="Email",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['email'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['email'].pack(fill="x", pady=(0, 10))
        
        # Contact Number
        ctk.CTkLabel(
            content,
            text="Contact Number",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['contact_number'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['contact_number'].pack(fill="x", pady=(0, 10))
        
        # Address
        ctk.CTkLabel(
            content,
            text="Address",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['address'] = ctk.CTkEntry(
            content,
            height=60,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['address'].pack(fill="x", pady=(0, 10))
        
        # Unit Selection (Dropdown with Unit Number and Rent)
        ctk.CTkLabel(
            content,
            text="Select Unit",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        # Get all units and filter by available capacity
        all_units = self.backend.get_all_units()
        available_units = []
        for u in all_units:
            tenants = self.backend.get_unit_tenants(u['unit_number'])
            max_tenants = u.get('max_tenants', 2)
            if len(tenants) < max_tenants:
                available_units.append(u)
        
        unit_options = [f"Unit {u['unit_number']} - ₱{u['default_rent']:,.0f}/month (Available)" for u in available_units]
        unit_map = {f"Unit {u['unit_number']} - ₱{u['default_rent']:,.0f}/month (Available)": u for u in available_units}
        
        if not unit_options:
            unit_options = ["No units available"]
        
        unit_var = ctk.StringVar(value=unit_options[0])
        unit_dropdown = ctk.CTkComboBox(
            content,
            values=unit_options,
            variable=unit_var,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            state="readonly"
        )
        unit_dropdown.pack(fill="x", pady=(0, 10))
        
        # Rent Amount (read-only, auto-filled from unit selection)
        ctk.CTkLabel(
            content,
            text="Rent Amount (₱)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        rent_display = ctk.CTkLabel(
            content,
            text="₱0.00",
            font=Config.FONT_BODY,
            text_color=Config.SUCCESS_COLOR
        )
        rent_display.pack(anchor="w", pady=(0, 10))
        
        entries['rent_amount'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['rent_amount'].pack(fill="x", pady=(0, 10))
        entries['rent_amount'].configure(state="disabled")
        
        def update_rent(*args):
            """Update rent amount when unit is selected"""
            selected = unit_var.get()
            if selected in unit_map:
                unit = unit_map[selected]
                rent_amount = unit['default_rent']
                rent_display.configure(text=f"₱{rent_amount:,.2f}")
                entries['rent_amount'].configure(state="normal")
                entries['rent_amount'].delete(0, "end")
                entries['rent_amount'].insert(0, str(rent_amount))
                entries['rent_amount'].configure(state="disabled")
        
        unit_var.trace("w", update_rent)
        update_rent()  # Initialize rent on load
        
        # Move In Date
        ctk.CTkLabel(
            content,
            text="Move In Date (YYYY-MM-DD)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['move_in_date'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['move_in_date'].pack(fill="x", pady=(0, 10))
        entries['move_in_date'].insert(0, datetime.now().strftime("%Y-%m-%d"))
        
        # (Notes field removed per request)
        
        def save():
            try:
                selected = unit_var.get()
                if selected not in unit_map:
                    messagebox.showerror("Error", "Please select a valid unit")
                    return
                
                unit = unit_map[selected]
                
                # Check if unit has reached maximum tenants
                unit_tenants = self.backend.get_unit_tenants(unit['unit_number'])
                max_tenants = unit.get('max_tenants', 2)
                if len(unit_tenants) >= max_tenants:
                    messagebox.showerror(
                        "Cannot Add Tenant",
                        f"Unit {unit['unit_number']} has reached its maximum capacity of {max_tenants} tenant(s).\n"
                        f"Current tenants: {len(unit_tenants)}"
                    )
                    return
                
                self.backend.create_tenant(
                    full_name=entries['full_name'].get(),
                    email=entries['email'].get(),
                    contact_number=entries['contact_number'].get(),
                    unit_number=unit['unit_number'],
                    rent_amount=float(entries['rent_amount'].get()),
                    move_in_date=entries['move_in_date'].get(),
                    address=entries['address'].get()
                )
                messagebox.showinfo("Success", "✓ Tenant added successfully!")
                dialog.destroy()
                self.show_tenants()
            except ValueError as e:
                messagebox.showerror("Error", f"Cannot add tenant:\n{str(e)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add tenant: {str(e)}")
        
        ctk.CTkButton(
            content,
            text="💾 Save Tenant",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x", pady=20)
    
    def _update_tenant_dialog(self, tenant):
        """Update tenant dialog"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Update Tenant")
        dialog.geometry("500x750")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        entries = {}
        
        # Full Name
        ctk.CTkLabel(content, text="Full Name", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['full_name'] = ctk.CTkEntry(content, height=40, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['full_name'].pack(fill="x", pady=(0, 10))
        entries['full_name'].insert(0, tenant['full_name'])
        
        # Email
        ctk.CTkLabel(content, text="Email", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['email'] = ctk.CTkEntry(content, height=40, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['email'].pack(fill="x", pady=(0, 10))
        entries['email'].insert(0, tenant['email'])
        
        # Contact Number
        ctk.CTkLabel(content, text="Contact Number", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['contact_number'] = ctk.CTkEntry(content, height=40, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['contact_number'].pack(fill="x", pady=(0, 10))
        entries['contact_number'].insert(0, tenant['contact_number'])
        
        # Address
        ctk.CTkLabel(content, text="Address", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['address'] = ctk.CTkEntry(content, height=60, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['address'].pack(fill="x", pady=(0, 10))
        entries['address'].insert(0, str(tenant.get('address', '') or ''))
        
        # Unit (editable dropdown)
        ctk.CTkLabel(content, text="Select Unit", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        
        # Get all available units
        all_units = self.backend.get_all_units()
        unit_options = [f"Unit {u['unit_number']}" for u in all_units]
        unit_map = {f"Unit {u['unit_number']}": u for u in all_units}
        
        unit_var = ctk.StringVar(value=f"Unit {tenant['unit_number']}")
        unit_dropdown = ctk.CTkComboBox(
            content,
            values=unit_options,
            variable=unit_var,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            state="readonly"
        )
        unit_dropdown.pack(fill="x", pady=(0, 10))
        
        # Rent Amount (updates when unit is selected)
        ctk.CTkLabel(content, text="Rent Amount (₱)", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        rent_display = ctk.CTkLabel(content, text=f"₱{tenant['rent_amount']:,.2f}", font=Config.FONT_BODY, text_color=Config.SUCCESS_COLOR)
        rent_display.pack(anchor="w", pady=(0, 10))
        
        def update_rent_on_unit_change(*args):
            """Update rent amount when unit is selected"""
            selected = unit_var.get()
            if selected in unit_map:
                unit = unit_map[selected]
                rent_display.configure(text=f"₱{unit['default_rent']:,.2f}")
        
        unit_var.trace("w", update_rent_on_unit_change)
        
        # Move In Date
        ctk.CTkLabel(content, text="Move In Date (YYYY-MM-DD)", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['move_in_date'] = ctk.CTkEntry(content, height=40, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['move_in_date'].pack(fill="x", pady=(0, 10))
        entries['move_in_date'].insert(0, tenant['move_in_date'])
        
        # Notes
        ctk.CTkLabel(content, text="Notes", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(anchor="w", pady=(12, 5))
        entries['notes'] = ctk.CTkEntry(content, height=80, font=Config.FONT_SMALL, fg_color=Config.BG_CARD, text_color=Config.TEXT_PRIMARY, border_color=Config.PRIMARY_COLOR, border_width=2, corner_radius=6)
        entries['notes'].pack(fill="x", pady=(0, 10))
        entries['notes'].insert(0, str(tenant.get('notes', '') or ''))
        
        def save():
            try:
                # Get selected unit number
                selected_unit = unit_var.get()
                new_unit_number = selected_unit.replace("Unit ", "")
                
                # Get new rent amount based on selected unit
                new_rent_amount = tenant['rent_amount']  # Default to current
                if selected_unit in unit_map:
                    new_rent_amount = unit_map[selected_unit]['default_rent']
                
                self.backend.update_tenant(
                    tenant_id=tenant['id'],
                    full_name=entries['full_name'].get(),
                    email=entries['email'].get(),
                    contact_number=entries['contact_number'].get(),
                    unit_number=new_unit_number,
                    rent_amount=new_rent_amount,
                    address=entries['address'].get(),
                    move_in_date=entries['move_in_date'].get(),
                    notes=entries['notes'].get()
                )
                messagebox.showinfo("Success", "✓ Tenant updated successfully!")
                dialog.destroy()
                self.show_tenants()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update tenant: {str(e)}")
        
        ctk.CTkButton(content, text="💾 Update Tenant", command=save, font=("Segoe UI", 12, "bold"), fg_color=Config.INFO_COLOR, hover_color="#3182CE", height=45, corner_radius=6).pack(fill="x", pady=20)
    
    def _delete_tenant(self, tenant_id):
        """Delete tenant with confirmation"""
        response = messagebox.askyesno(
            "Confirm Delete",
            "Are you sure you want to delete this tenant?\nThis action cannot be undone."
        )
        
        if response:
            try:
                self.backend.delete_tenant(tenant_id)
                messagebox.showinfo("Success", "✓ Tenant deleted successfully!")
                self.show_tenants()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete tenant: {str(e)}")
    
    def show_units(self):
        """Show units view with all units and vacant units tabs"""
        self._clear_content()
        
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="🏠 Unit Management",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        ctk.CTkButton(
            title_frame,
            text="➕ Add Unit",
            command=self._add_unit_dialog,
            font=Config.FONT_SMALL,
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        units = self.backend.get_all_units()
        
        if not units:
            ctk.CTkLabel(
                self.content_frame,
                text="No units found",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        # Tab buttons for filtering
        tab_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        tab_frame.pack(fill="x", pady=(0, 20))
        
        tab_state = {"current": "all"}  # State holder
        
        def show_all_units():
            tab_state["current"] = "all"
            self._display_units_view(units, "all")
        
        def show_available_units():
            tab_state["current"] = "available"
            self._display_units_view(units, "available")
        
        all_btn = ctk.CTkButton(
            tab_frame,
            text=f"📊 All Units ({len(units)})",
            command=show_all_units,
            font=Config.FONT_SMALL,
            fg_color=Config.PRIMARY_COLOR,
            hover_color="#4A7C9E",
            height=35,
            corner_radius=6
        )
        all_btn.pack(side="left", padx=(0, 10))
        
        available_units = [u for u in units if u.get('available_slots', 0) > 0]
        available_btn = ctk.CTkButton(
            tab_frame,
            text=f"🟢 Available Slots ({len(available_units)})",
            command=show_available_units,
            font=Config.FONT_SMALL,
            fg_color=Config.SECONDARY_COLOR,
            hover_color="#5A3A7A",
            height=35,
            corner_radius=6
        )
        available_btn.pack(side="left")
        
        # Display all units by default
        self._display_units_view(units, "all")
    
    def _display_units_view(self, units, view_type):
        """Display units based on view type (all or available)"""
        # Clear previous content
        for widget in self.content_frame.winfo_children():
            if widget.winfo_y() > 100:  # Keep header
                widget.destroy()
        
        if view_type == "available":
            display_units = [u for u in units if u.get('available_slots', 0) > 0]
            
            if not display_units:
                ctk.CTkLabel(
                    self.content_frame,
                    text="✅ All units are at full capacity!",
                    font=Config.FONT_BODY,
                    text_color=Config.SUCCESS_COLOR
                ).pack(pady=40)
                return
            
            # Summary for available units
            total_available_slots = sum(u.get('available_slots', 0) for u in display_units)
            fully_vacant = [u for u in display_units if u.get('current_tenant_count', 0) == 0]
            
            summary_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            summary_frame.pack(fill="x", pady=(0, 20))
            
            summary_content = ctk.CTkFrame(summary_frame, fg_color=Config.BG_CARD)
            summary_content.pack(fill="both", expand=True, padx=20, pady=15)
            
            ctk.CTkLabel(
                summary_content,
                text=f"📊 {len(display_units)} unit(s) with available slots | {len(fully_vacant)} completely vacant | {total_available_slots} total slots available",
                font=("Segoe UI", 12, "bold"),
                text_color=Config.ACCENT_COLOR
            ).pack(anchor="w")
            
            # Sort by available slots
            display_units = sorted(display_units, key=lambda x: x.get('available_slots', 0), reverse=True)
        else:
            # Show all units
            display_units = units
        
        for unit in display_units:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            card.pack(fill="x", pady=10)
            
            content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            content.pack(fill="both", expand=True, padx=20, pady=15)
            
            # Unit number and status
            header_frame = ctk.CTkFrame(content, fg_color=Config.BG_CARD)
            header_frame.pack(fill="x", pady=(0, 10))
            
            ctk.CTkLabel(
                header_frame,
                text=f"🏢 Unit {unit['unit_number']}",
                font=Config.FONT_SUBTITLE,
                text_color=Config.ACCENT_COLOR
            ).pack(anchor="w", side="left")
            
            # Check if unit is at capacity
            max_tenants = unit.get('max_tenants', 2)
            current_tenants = unit.get('current_tenant_count', 0)
            available_slots = unit.get('available_slots', max_tenants - current_tenants)
            is_full = current_tenants >= max_tenants
            
            capacity_status = "🔴 FULL" if is_full else f"🟢 {available_slots} available"
            capacity_color = Config.DANGER_COLOR if is_full else Config.SUCCESS_COLOR
            
            ctk.CTkLabel(
                header_frame,
                text=capacity_status,
                font=Config.FONT_SMALL,
                text_color=capacity_color
            ).pack(anchor="e", side="right")
            
            status = "✅ Occupied" if unit['occupied'] else "⭕ Vacant"
            status_color = Config.SUCCESS_COLOR if unit['occupied'] else Config.WARNING_COLOR
            
            ctk.CTkLabel(
                content,
                text=status,
                font=Config.FONT_SMALL,
                text_color=status_color
            ).pack(anchor="w", pady=(5, 0))
            
            ctk.CTkLabel(
                content,
                text=f"Default Rent: ₱{unit['default_rent']:,.2f}",
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=(3, 0))
            
            # Capacity bar
            capacity_frame = ctk.CTkFrame(content, fg_color=Config.BG_DARKER, corner_radius=4)
            capacity_frame.pack(fill="x", pady=(8, 3))
            
            capacity_percentage = (current_tenants / max_tenants * 100) if max_tenants > 0 else 0
            bar_color = Config.DANGER_COLOR if capacity_percentage >= 100 else (Config.WARNING_COLOR if capacity_percentage >= 75 else Config.SUCCESS_COLOR)
            
            capacity_bar = ctk.CTkFrame(capacity_frame, fg_color=bar_color, corner_radius=4, height=8)
            capacity_bar.pack(side="left", fill="x", expand=True, padx=2, pady=2)
            capacity_bar.configure(width=int(200 * capacity_percentage / 100) if capacity_percentage > 0 else 0)
            
            ctk.CTkLabel(
                content,
                text=f"Occupancy: {current_tenants}/{max_tenants} tenants ({capacity_percentage:.0f}%)",
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=(3, 0))
            
            # Get tenants in this unit
            try:
                tenants_in_unit = self.backend.get_unit_tenants(unit['unit_number'])
            except Exception as e:
                print(f"Error fetching tenants for unit {unit['unit_number']}: {str(e)}")
                tenants_in_unit = []
            
            # Display tenant list
            if tenants_in_unit:
                tenants_frame = ctk.CTkFrame(content, fg_color=Config.BG_DARKER, corner_radius=6)
                tenants_frame.pack(fill="x", pady=(10, 0))
                
                ctk.CTkLabel(
                    tenants_frame,
                    text=f"👥 Occupants ({len(tenants_in_unit)}):",
                    font=("Segoe UI", 11, "bold"),
                    text_color=Config.ACCENT_COLOR
                ).pack(anchor="w", padx=12, pady=(8, 5))
                
                for tenant in tenants_in_unit:
                    try:
                        full_name = tenant.get('full_name', 'Unknown')
                        contact = tenant.get('contact_number', 'N/A')
                        tenant_info = f"• {full_name} ({contact})"
                        ctk.CTkLabel(
                            tenants_frame,
                            text=tenant_info,
                            font=Config.FONT_SMALL,
                            text_color=Config.TEXT_SECONDARY
                        ).pack(anchor="w", padx=20, pady=2)
                    except Exception as e:
                        print(f"Error displaying tenant info: {str(e)}")
                        continue
                
                ctk.CTkLabel(tenants_frame, text="").pack(pady=3)
            else:
                # No tenants in unit
                ctk.CTkLabel(
                    content,
                    text="👥 No tenants assigned",
                    font=Config.FONT_SMALL,
                    text_color=Config.WARNING_COLOR
                ).pack(anchor="w", pady=(8, 0))
            
            # Action buttons
            button_frame = ctk.CTkFrame(content, fg_color=Config.BG_CARD)
            button_frame.pack(fill="x", pady=(15, 0))
            
            ctk.CTkButton(
                button_frame,
                text="✏️ Edit Unit",
                command=lambda u=unit: self._edit_unit_dialog(u),
                font=Config.FONT_SMALL,
                fg_color=Config.INFO_COLOR,
                hover_color="#3182CE",
                height=35,
                corner_radius=6
            ).pack(side="left", padx=(0, 5), fill="x", expand=True)
            
            ctk.CTkButton(
                button_frame,
                text="🗑️ Delete",
                command=lambda unit_id=unit['id']: self._delete_unit(unit_id),
                font=Config.FONT_SMALL,
                fg_color=Config.DANGER_COLOR,
                hover_color="#E53E3E",
                height=35,
                corner_radius=6
            ).pack(side="left", fill="x", expand=True)


    
    def _add_unit_dialog(self):
        """Add unit dialog"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Add New Unit")
        dialog.geometry("400x450")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            content,
            text="Unit Number",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        unit_entry = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        unit_entry.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            content,
            text="Default Rent (₱)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        rent_entry = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        rent_entry.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            content,
            text="Max Tenants",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        max_tenants_entry = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        max_tenants_entry.pack(fill="x", pady=(0, 30))
        max_tenants_entry.insert(0, "2")  # Default value
        
        def save():
            try:
                self.backend.create_unit(
                    unit_number=unit_entry.get(),
                    default_rent=float(rent_entry.get()) if rent_entry.get() else 0,
                    max_tenants=int(max_tenants_entry.get()) if max_tenants_entry.get() else 2
                )
                messagebox.showinfo("Success", "✓ Unit added successfully!")
                dialog.destroy()
                self.show_units()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add unit: {str(e)}")
        
        ctk.CTkButton(
            content,
            text="💾 Save Unit",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x")
    
    def _edit_unit_dialog(self, unit):
        """Edit unit dialog - change unit number and max tenants"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Unit")
        dialog.geometry("400x450")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            content,
            text="Unit Number",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        unit_entry = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        unit_entry.pack(fill="x", pady=(0, 20))
        unit_entry.insert(0, unit['unit_number'])
        
        ctk.CTkLabel(
            content,
            text="Default Rent (₱)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        rent_label = ctk.CTkLabel(
            content,
            text=f"₱{unit['default_rent']:,.2f}",
            font=Config.FONT_BODY,
            text_color=Config.SUCCESS_COLOR
        )
        rent_label.pack(anchor="w", pady=(0, 20))
        
        ctk.CTkLabel(
            content,
            text="Max Tenants",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 8))
        
        max_tenants_entry = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        max_tenants_entry.pack(fill="x", pady=(0, 30))
        max_tenants_entry.insert(0, str(unit['max_tenants']))
        
        def save():
            try:
                new_unit_number = unit_entry.get()
                if not new_unit_number.strip():
                    messagebox.showwarning("Validation Error", "Unit number cannot be empty.")
                    return
                
                new_max_tenants = int(max_tenants_entry.get()) if max_tenants_entry.get() else unit['max_tenants']
                
                # Validate max_tenants is positive
                if new_max_tenants < 1:
                    messagebox.showwarning(
                        "Validation Error", 
                        "Maximum tenants must be at least 1."
                    )
                    return
                
                # Get current tenant count in this unit
                unit_tenants = self.backend.get_unit_tenants(unit['unit_number'])
                current_tenant_count = len(unit_tenants)
                
                # Validate max_tenants is not being decreased below current tenant count
                if new_max_tenants < current_tenant_count:
                    messagebox.showerror(
                        "Cannot Decrease Max Tenants",
                        f"Cannot set max tenants to {new_max_tenants}.\n\n"
                        f"Unit {unit['unit_number']} currently has {current_tenant_count} tenant(s).\n"
                        f"Maximum must be at least {current_tenant_count}."
                    )
                    return
                
                # Update unit
                self.backend.update_unit(
                    unit_id=unit['id'],
                    unit_number=new_unit_number,
                    max_tenants=new_max_tenants
                )
                messagebox.showinfo("Success", "✓ Unit updated successfully!")
                dialog.destroy()
                self.show_units()
            except ValueError as e:
                messagebox.showerror("Validation Error", str(e))
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update unit: {str(e)}")
        
        ctk.CTkButton(
            content,
            text="💾 Update Unit",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.INFO_COLOR,
            hover_color="#3182CE",
            height=45,
            corner_radius=6
        ).pack(fill="x")
    
    def _delete_unit(self, unit_id):
        """Delete unit with confirmation"""
        response = messagebox.askyesno(
            "Confirm Delete",
            "Are you sure you want to delete this unit?\nThis action cannot be undone."
        )
        
        if response:
            try:
                self.backend.delete_unit(unit_id)
                messagebox.showinfo("Success", "✓ Unit deleted successfully!")
                self.show_units()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete unit: {str(e)}")
    
    def show_unpaid_tenants(self):
        """Show unpaid tenants view - tenants with pending and partial billings"""
        self._clear_content()
        
        # Title
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", padx=20, pady=(20, 15))
        
        ctk.CTkLabel(
            title_frame,
            text="❌ Unpaid Billings",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        ctk.CTkButton(
            title_frame,
            text="🔄 Refresh",
            command=self.show_unpaid_tenants,
            font=Config.FONT_SMALL,
            fg_color=Config.SECONDARY_COLOR,
            hover_color="#5A3A7A",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        # Get tenant-level billings and consider pending/partial/overdue as unpaid
        billings = self.backend.get_all_tenant_billings()
        unpaid_billings = [b for b in billings if b.get('status') in ('pending', 'partially_paid', 'overdue')]
        
        if unpaid_billings:
            # Calculate summary statistics using current balances (avoid negative values)
            total_unpaid = 0.0
            overdue_count = 0
            pending_count = 0
            for b in unpaid_billings:
                try:
                    tb_with_payments = self.backend.get_tenant_billing_with_payments(b.get('id'))
                    balance = float(tb_with_payments.get('balance', b.get('total_amount', 0))) if tb_with_payments else float(b.get('total_amount', 0))
                except Exception:
                    balance = float(b.get('total_amount', 0) or 0)
                balance = max(0.0, balance)
                total_unpaid += balance
                if b.get('status') == 'overdue':
                    overdue_count += 1
                if b.get('status') == 'pending':
                    pending_count += 1
            
            # Summary statistics card
            stats_card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            stats_card.pack(fill="x", padx=20, pady=(0, 20))
            
            stats_content = ctk.CTkFrame(stats_card, fg_color=Config.BG_CARD)
            stats_content.pack(fill="both", expand=True, padx=15, pady=12)
            
            ctk.CTkLabel(
                stats_content,
                text=f"💰 Total Unpaid: ₱{total_unpaid:,.2f}",
                font=("Segoe UI", 14, "bold"),
                text_color=Config.WARNING_COLOR
            ).pack(anchor="w", pady=(0, 8))
            
            stats_breakdown = f"⚠️ Overdue: {overdue_count} | 🔴 Unpaid: {pending_count}"
            ctk.CTkLabel(
                stats_content,
                text=stats_breakdown,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w")
            
            # Sort billings by urgency: overdue first, then pending, then partial
            sort_order = {'overdue': 0, 'pending': 1, 'partially_paid': 2}
            unpaid_billings_sorted = sorted(unpaid_billings, key=lambda x: sort_order.get(x.get('status'), 3))
            
            # Create billings list inside scrollable container
            for billing in unpaid_billings_sorted:
                try:
                    tenant = self.backend.get_tenant(billing['tenant_id'])
                    tenant_name = tenant['full_name'] if tenant else f"Tenant {billing['tenant_id']}"
                    unit_number = tenant.get('unit_number', 'N/A') if tenant else 'N/A'
                except:
                    tenant_name = f"Tenant {billing['tenant_id']}"
                    unit_number = 'N/A'
                
                st = billing.get('status')
                status_icon = "⚠️" if st == 'overdue' else ("🔴" if st == 'pending' else "🟡")
                status_color = "#E74C3C" if st == 'overdue' else (Config.WARNING_COLOR if st == 'pending' else "#FF9500")
                
                item = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=8)
                item.pack(fill="x", padx=20, pady=8)
                
                info_frame = ctk.CTkFrame(item, fg_color=Config.BG_CARD)
                info_frame.pack(fill="x", padx=15, pady=12)
                
                # Header line with tenant name and amount
                header = ctk.CTkFrame(info_frame, fg_color=Config.BG_CARD)
                header.pack(fill="x", pady=(0, 8))
                
                ctk.CTkLabel(
                    header,
                    text=f"{status_icon} {tenant_name} (Unit {unit_number})",
                    font=Config.FONT_BODY,
                    text_color=status_color
                ).pack(side="left")
                
                # Show current balance (not original total_amount)
                try:
                    tb_with_payments = self.backend.get_tenant_billing_with_payments(billing.get('id'))
                    display_amount = max(0.0, float(tb_with_payments.get('balance', billing.get('total_amount', 0)))) if tb_with_payments else float(billing.get('total_amount', 0) or 0)
                except Exception:
                    display_amount = float(billing.get('total_amount', 0) or 0)

                ctk.CTkLabel(
                    header,
                    text=f"₱{display_amount:,.2f}",
                    font=("Segoe UI", 12, "bold"),
                    text_color=Config.WARNING_COLOR
                ).pack(side="right")
                
                # Details line - show 'UNPAID' instead of 'PENDING' for clarity
                st = billing.get('status', '')
                display_status = 'UNPAID' if st == 'pending' else st.upper()
                ctk.CTkLabel(
                    info_frame,
                    text=f"Billing Month: {billing.get('billing_month', 'N/A')} | Due: {billing.get('due_date', 'N/A')} | Status: {display_status}",
                    font=Config.FONT_SMALL,
                    text_color=Config.TEXT_SECONDARY
                ).pack(anchor="w")
        else:
            ctk.CTkLabel(
                self.content_frame,
                text="✓ No unpaid billings - All tenants are up to date!",
                font=Config.FONT_BODY,
                text_color=Config.SUCCESS_COLOR
            ).pack(pady=40)
    
    def show_occupancy(self):
        """Show unit occupancy details"""
        self._clear_content()
        
        ctk.CTkLabel(
            self.content_frame,
            text="🏢 Unit Occupancy Status",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 30))
        
        report = self.backend.get_occupancy_report()
        
        # Calculate fully occupied and partially occupied units
        all_units = self.backend.get_all_units()
        fully_occupied = len([u for u in all_units if u['current_tenant_count'] == u['max_tenants'] and u['current_tenant_count'] > 0])
        partially_occupied = len([u for u in all_units if 0 < u['current_tenant_count'] < u['max_tenants']])
        completely_vacant = len([u for u in all_units if u['current_tenant_count'] == 0])
        
        # Summary stats
        stats_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        stats_frame.pack(fill="x", pady=20)
        
        self._create_stat_card(
            stats_frame,
            "Total Units",
            report['total_units'],
            "🏢",
            Config.PRIMARY_COLOR
        )
        self._create_stat_card(
            stats_frame,
            "Fully Occupied",
            fully_occupied,
            "✅",
            Config.SUCCESS_COLOR
        )
        self._create_stat_card(
            stats_frame,
            "Not Fully Occupied",
            partially_occupied + completely_vacant,
            "🟡",
            Config.WARNING_COLOR
        )
        self._create_stat_card(
            stats_frame,
            "Occupancy Rate",
            f"{report['occupancy_rate']:.1f}%",
            "📊",
            Config.INFO_COLOR
        )
        
        # Capacity usage
        ctk.CTkLabel(
            self.content_frame,
            text="📈 Capacity Usage",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        capacity_info = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
        capacity_info.pack(fill="x", pady=15)
        
        capacity_content = ctk.CTkFrame(capacity_info, fg_color=Config.BG_CARD)
        capacity_content.pack(fill="both", expand=True, padx=20, pady=15)
        
        ctk.CTkLabel(
            capacity_content,
            text=f"Total Capacity: {report['total_capacity']} beds",
            font=Config.FONT_BODY,
            text_color=Config.TEXT_SECONDARY
        ).pack(anchor="w", pady=5)
        
        ctk.CTkLabel(
            capacity_content,
            text=f"Currently Occupied: {report['total_occupied']} beds",
            font=Config.FONT_BODY,
            text_color=Config.SUCCESS_COLOR
        ).pack(anchor="w", pady=5)
        
        ctk.CTkLabel(
            capacity_content,
            text=f"Available Slots: {report['total_available_slots']} beds",
            font=Config.FONT_BODY,
            text_color=Config.INFO_COLOR
        ).pack(anchor="w", pady=5)
        
        ctk.CTkLabel(
            capacity_content,
            text=f"Capacity Usage: {report['capacity_usage']:.1f}%",
            font=("Segoe UI", 14, "bold"),
            text_color=Config.PRIMARY_COLOR
        ).pack(anchor="w", pady=10)
        
        # Units list
        ctk.CTkLabel(
            self.content_frame,
            text="Unit Details",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        for unit in report['units']:
            # Determine unit status color
            if unit['is_full']:
                status_color = Config.DANGER_COLOR
                status_text = "🔴 FULL"
            elif unit['is_vacant']:
                status_color = Config.WARNING_COLOR
                status_text = "⭕ VACANT"
            else:
                status_color = Config.SUCCESS_COLOR
                status_text = f"🟢 {unit['current_tenant_count']}/{unit['max_tenants']} Tenants"
            
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            card.pack(fill="x", pady=10)
            
            content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            content.pack(fill="both", expand=True, padx=20, pady=15)
            
            # Unit number and status
            header_frame = ctk.CTkFrame(content, fg_color=Config.BG_CARD)
            header_frame.pack(fill="x", pady=(0, 10))
            
            ctk.CTkLabel(
                header_frame,
                text=f"Unit {unit['unit_number']}",
                font=Config.FONT_SUBTITLE,
                text_color=Config.ACCENT_COLOR
            ).pack(side="left")
            
            ctk.CTkLabel(
                header_frame,
                text=status_text,
                font=("Segoe UI", 12, "bold"),
                text_color=status_color
            ).pack(side="right")
            
            # Details
            ctk.CTkLabel(
                content,
                text=f"💰 Rent: ₱{unit['default_rent']:,.2f}",
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=3)
            
            ctk.CTkLabel(
                content,
                text=f"👥 Capacity: {unit['current_tenant_count']}/{unit['max_tenants']} | Available Slots: {unit['available_slots']}",
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=3)
            
            ctk.CTkLabel(
                content,
                text=f"📊 Occupancy: {unit['occupancy_percentage']:.1f}%",
                font=Config.FONT_SMALL,
                text_color=Config.INFO_COLOR
            ).pack(anchor="w", pady=(3, 10))
            
            # Show tenants occupying this unit
            try:
                unit_tenants = self.backend.get_unit_tenants(unit['unit_number'])
                if unit_tenants:
                    tenants_label = ctk.CTkLabel(
                        content,
                        text=f"👥 Occupying Tenants ({len(unit_tenants)}):",
                        font=("Segoe UI", 11, "bold"),
                        text_color=Config.ACCENT_COLOR
                    )
                    tenants_label.pack(anchor="w", pady=(8, 5))
                    
                    for tenant in unit_tenants:
                        tenant_info = f"  • {tenant['full_name']} (Unit {tenant['unit_number']}) - ₱{tenant['rent_amount']:,.2f}/month"
                        ctk.CTkLabel(
                            content,
                            text=tenant_info,
                            font=Config.FONT_SMALL,
                            text_color=Config.TEXT_SECONDARY
                        ).pack(anchor="w", pady=1)
            except Exception as e:
                print(f"Error fetching tenants for unit {unit['unit_number']}: {str(e)}")
    
    def show_billings(self):
        """Show billings view"""
        self._clear_content()
        
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="📋 Billing Management",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        buttons_frame = ctk.CTkFrame(title_frame, fg_color=Config.BG_DARK)
        buttons_frame.pack(side="right")
        
        ctk.CTkButton(
            buttons_frame,
            text="📊 Tenant Billings",
            command=self.show_tenant_billings,
            font=Config.FONT_SMALL,
            fg_color=Config.PRIMARY_COLOR,
            hover_color="#4A7C9E",
            height=40,
            corner_radius=6
        ).pack(side="right", padx=(10, 0))
        
        # (Advance access moved to sidebar)
        
        ctk.CTkButton(
            buttons_frame,
            text="➕ Create Billing",
            command=self._add_billing_dialog,
            font=Config.FONT_SMALL,
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        billings = self.backend.get_all_billings()
        
        if not billings:
            ctk.CTkLabel(
                self.content_frame,
                text="No billings found",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        for billing in billings:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            card.pack(fill="x", pady=10)
            
            # Get number of tenants in this unit
            try:
                unit_tenants = self.backend.get_unit_tenants(billing['unit_number'])
                num_tenants = len(unit_tenants)
            except:
                num_tenants = 1
            
            # Get tenant-level billings for this billing (if any) - exclude paid tenants from amount_to_collect
            tenant_billings_for_unit = [tb for tb in self.backend.get_all_tenant_billings() if tb.get('billing_id') == billing.get('id')]
            
            # Count unpaid/pending tenants only (paid tenants don't contribute to amount_to_collect)
            unpaid_tenant_billings = [tb for tb in tenant_billings_for_unit if tb.get('status') != 'paid']
            num_unpaid_tenants = len(unpaid_tenant_billings)

            # Calculate unit-level total and per-tenant amount (from unpaid tenants only)
            unit_level_total = billing.get('total_amount', billing.get('total_water', 0) + billing.get('total_electricity', 0) + billing.get('total_wifi', 0) + billing.get('rent', 0))
            if unpaid_tenant_billings:
                try:
                    # per-tenant amount: average of unpaid tenant total_amounts
                    total_to_pay = sum(float(tb.get('total_amount', 0) or 0) for tb in unpaid_tenant_billings) / max(1, len(unpaid_tenant_billings))
                except Exception:
                    total_to_pay = unit_level_total / max(1, num_unpaid_tenants) if num_unpaid_tenants > 0 else 0
            else:
                total_to_pay = 0

            # Unit total expected = per-tenant amount * number of unpaid tenants
            unit_total_billing = total_to_pay * max(1, num_unpaid_tenants)

            # Sum payments applied to unpaid tenant billings only (paid tenants don't count)
            all_payments = self.backend.get_all_payments() or []
            total_paid = 0.0
            for payment in all_payments:
                try:
                    if payment.get('tenant_billing_id'):
                        tb_for_payment = next((tb for tb in unpaid_tenant_billings if tb.get('id') == payment.get('tenant_billing_id')), None)
                        if tb_for_payment:
                            if payment.get('amount_paid', 0) > 0:
                                total_paid += float(payment.get('amount_paid', 0))
                    elif payment.get('billing_month') == billing.get('billing_month'):
                        if payment.get('amount_paid', 0) > 0:
                            total_paid += float(payment.get('amount_paid', 0))
                except Exception:
                    continue

            # Amount to be collected = (per-tenant × unpaid tenants) - payments made on unpaid
            amount_to_collect = max(0.0, unit_total_billing - total_paid)

            # Compute a billing-level status from tenant billing statuses/payments
            if num_unpaid_tenants == 0:
                billing_status = 'paid'
            else:
                
                billing_status = 'unpaid'
            
            # Header with info and buttons
            header = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            header.pack(fill="x", padx=20, pady=(15, 10))
            
            # Left side - billing info
            info_frame = ctk.CTkFrame(header, fg_color=Config.BG_CARD)
            info_frame.pack(side="left", fill="both", expand=True)
            
            ctk.CTkLabel(
                info_frame,
                text=f"📋 Unit {billing['unit_number']} - {billing['billing_month']} | 👥 {num_tenants} tenant(s)",
                font=Config.FONT_SUBTITLE,
                text_color=Config.ACCENT_COLOR
            ).pack(anchor="w")
            
            breakdown = f"💧 Water: ₱{billing['total_water']:.2f} | ⚡ Electricity: ₱{billing['total_electricity']:.2f} | 📡 WiFi: ₱{billing['total_wifi']:.2f} | 🏠 Rent: ₱{billing.get('rent', 0):.2f}"
            ctk.CTkLabel(
                info_frame,
                text=breakdown,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=(5, 0))
            
            
            
            # Amount to be collected info and status
            due_color = Config.SUCCESS_COLOR if amount_to_collect == 0 else ("#FF9500" if amount_to_collect > 0 else Config.PRIMARY_COLOR)
            amount_due_text = f"💰 Total per Tenant: ₱{total_to_pay:,.2f} | 📊 Amount to be Collected: ₱{amount_to_collect:,.2f}"
            ctk.CTkLabel(
                info_frame,
                text=amount_due_text,
                font=("Segoe UI", 12, "bold"),
                text_color=due_color
            ).pack(anchor="w", pady=(5, 0))

            # Show per-tenant billing info based on tenant_billings (if available)
            try:
                if tenant_billings_for_unit:
                    tenants_frame = ctk.CTkFrame(info_frame, fg_color=Config.BG_CARD)
                    tenants_frame.pack(fill="x", pady=(8, 0))
                    ctk.CTkLabel(tenants_frame, text="Tenants Billing:", font=Config.FONT_SMALL, text_color=Config.ACCENT_COLOR).pack(anchor="w")
                    for tb in tenant_billings_for_unit:
                        try:
                            tenant = self.backend.get_tenant(tb.get('tenant_id'))
                            name = tenant.get('full_name') if tenant else f"Tenant {tb.get('tenant_id')}"
                        except Exception:
                            name = f"Tenant {tb.get('tenant_id')}"

                        # Fetch payments and balance for this tenant billing
                        tb_with_payments = self.backend.get_tenant_billing_with_payments(tb.get('id'))
                        paid = tb_with_payments.get('total_paid', 0) if tb_with_payments else 0
                        balance = tb_with_payments.get('balance', tb.get('total_amount', 0)) if tb_with_payments else tb.get('total_amount', 0)

                        line = f" - {name}: ₱{tb.get('total_amount', 0):,.2f} | Paid: ₱{paid:,.2f} | Balance: ₱{balance:,.2f}"
                        ctk.CTkLabel(tenants_frame, text=line, font=Config.FONT_SMALL, text_color=Config.TEXT_SECONDARY).pack(anchor="w", padx=(8,0))
            except Exception:
                # Fallback: no tenant-level breakdown
                pass
            
            # Status badge
            status_map = {
                'pending': ('⏳ UNPAID', Config.SECONDARY_COLOR),
                'partially_paid': ('📊 PARTIALLY PAID', "#FF9500"),
                'paid': ('✅ PAID', Config.SUCCESS_COLOR),
                'overdue': ('⚠️ OVERDUE', "#E74C3C")
            }
            status_text, status_color = status_map.get(billing_status if 'billing_status' in locals() else billing.get('status', 'pending'), ('❌ UNPAID', Config.TEXT_SECONDARY))
            ctk.CTkLabel(
                info_frame,
                text=status_text,
                font=("Segoe UI", 11, "bold"),
                text_color=status_color
            ).pack(anchor="w", pady=(8, 0))
            
            # Right side - action buttons
            button_frame = ctk.CTkFrame(header, fg_color=Config.BG_CARD)
            button_frame.pack(side="right")
            
            ctk.CTkButton(
                button_frame,
                text="✏️ Edit",
                command=lambda b=billing: self._edit_billing_dialog(b),
                font=Config.FONT_SMALL,
                fg_color=Config.PRIMARY_COLOR,
                hover_color="#4A7C9E",
                height=32,
                width=80,
                corner_radius=6
            ).pack(side="left", padx=(0, 5))
            
            ctk.CTkButton(
                button_frame,
                text="🗑️ Delete",
                command=lambda b=billing: self._delete_billing(b),
                font=Config.FONT_SMALL,
                fg_color="#E74C3C",
                hover_color="#C0392B",
                height=32,
                width=80,
                corner_radius=6
            ).pack(side="left")
    
    def _add_billing_dialog(self):
        """Add billing dialog - creates billing and assigns to all tenants in selected unit"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Create New Billing")
        dialog.geometry("550x820")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Get all units
        all_units = self.backend.get_all_units()
        unit_options = [str(u['unit_number']) for u in all_units]
        
        # Unit Selection
        ctk.CTkLabel(
            content,
            text="Select Unit",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        unit_combo = ctk.CTkComboBox(
            content,
            values=unit_options,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            button_color=Config.PRIMARY_COLOR,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        unit_combo.pack(fill="x", pady=(0, 15))
        if unit_options:
            unit_combo.set(unit_options[0])
        
        tenants_label = ctk.CTkLabel(
            content,
            text="Tenants in Unit",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        )
        tenants_label.pack(anchor="w", pady=(12, 5))
        
        tenants_frame = ctk.CTkFrame(
            content,
            fg_color=Config.BG_CARD,
            border_color=Config.PRIMARY_COLOR,
            border_width=1,
            corner_radius=6
        )
        tenants_frame.pack(fill="x", pady=(0, 15), padx=0)
        
        tenants_text = ctk.CTkLabel(
            tenants_frame,
            text="",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_SECONDARY,
            justify="left"
        )
        tenants_text.pack(fill="both", padx=10, pady=10)
        
        # Billing details
        fields = [
            ("Billing Month (YYYY-MM)", "billing_month"),
            ("Due Date (YYYY-MM-DD)", "due_date"),
            ("Water Cost (₱)", "total_water"),
            ("Electricity Cost (₱)", "total_electricity"),
            ("WiFi Cost (₱)", "total_wifi"),
            ("Rent (₱)", "rent"),
        ]
        
        entries = {}
        for label, key in fields:
            ctk.CTkLabel(
                content,
                text=label,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_PRIMARY
            ).pack(anchor="w", pady=(12, 5))
            
            entry = ctk.CTkEntry(
                content,
                height=40,
                font=Config.FONT_SMALL,
                fg_color=Config.BG_CARD,
                text_color=Config.TEXT_PRIMARY,
                border_color=Config.PRIMARY_COLOR,
                border_width=2,
                corner_radius=6
            )
            entry.pack(fill="x", pady=(0, 10))
            entries[key] = entry
        
        def update_tenants(*args):
            """Update tenants display and auto-fill rent when unit is selected"""
            unit_number = unit_combo.get()
            if unit_number:
                try:
                    tenants = self.backend.get_tenants_by_unit(str(unit_number))
                    if tenants:
                        tenant_list = "\n".join([f"👤 {t['full_name']} ({t['contact_number']})" for t in tenants])
                        tenants_text.configure(text=tenant_list, text_color=Config.TEXT_PRIMARY)
                    else:
                        tenants_text.configure(text="❌ No tenants in this unit", text_color=Config.TEXT_SECONDARY)
                    
                    # Auto-fill rent entry with unit's default rent
                    unit = next((u for u in all_units if str(u['unit_number']) == unit_number), None)
                    if unit and unit.get('default_rent') and 'rent' in entries:
                        entries['rent'].delete(0, "end")
                        entries['rent'].insert(0, str(unit['default_rent']))
                    
                except Exception as e:
                    tenants_text.configure(text=f"Error: {str(e)}", text_color="red")
                    print(f"Error in update_tenants: {str(e)}")
        
        unit_combo.configure(command=update_tenants)
        
        def save():
            try:
                unit_number = str(unit_combo.get())
                if not unit_number or unit_number == "":
                    messagebox.showerror("Error", "Please select a unit")
                    return
                
                # Validate inputs
                if not entries['billing_month'].get():
                    messagebox.showerror("Error", "Please enter billing month")
                    return
                if not entries['due_date'].get():
                    messagebox.showerror("Error", "Please enter due date")
                    return
                
                # Create the billing
                billing_id = self.backend.create_billing(
                    unit_number=unit_number,
                    billing_month=entries['billing_month'].get(),
                    due_date=entries['due_date'].get(),
                    total_water=float(entries['total_water'].get()) if entries['total_water'].get() else 0,
                    total_electricity=float(entries['total_electricity'].get()) if entries['total_electricity'].get() else 0,
                    total_wifi=float(entries['total_wifi'].get()) if entries['total_wifi'].get() else 0,
                    rent=float(entries['rent'].get()) if entries['rent'].get() else 0,
                )
                
                # Get all tenants in the unit
                tenants = self.backend.get_tenants_by_unit(unit_number)
                
                if not tenants:
                    messagebox.showwarning("Warning", "Billing created but no active tenants found in this unit")
                    dialog.destroy()
                    self.show_billings()
                    return
                
                # Calculate shares per tenant
                num_tenants = len(tenants)

                # Get billing details for share calculation
                billing = self.backend.get_billing(billing_id)

                success_count = 0
                for tenant in tenants:
                    try:
                        # Utilities (water, electricity, wifi) are split evenly among tenants
                        water_share = float(billing.get('total_water', 0) or 0) / num_tenants if num_tenants else 0
                        electricity_share = float(billing.get('total_electricity', 0) or 0) / num_tenants if num_tenants else 0
                        wifi_share = float(billing.get('total_wifi', 0) or 0) / num_tenants if num_tenants else 0

                        # Rent: prefer tenant-specific `rent_amount` when present (>0).
                        # If tenant has no rent_amount, fall back to evenly splitting billing rent.
                        tenant_rent = tenant.get('rent_amount') if tenant.get('rent_amount') is not None else 0
                        try:
                            tenant_rent = float(tenant_rent)
                        except Exception:
                            tenant_rent = 0

                        if tenant_rent and tenant_rent > 0:
                            rent_share = tenant_rent
                        else:
                            rent_share = float(billing.get('rent', 0) or 0) / num_tenants if num_tenants else 0

                        # Create tenant_billing (auto-assigns OVERDUE status if past due)
                        self.backend.create_tenant_billing(
                            tenant_id=tenant['id'],
                            billing_id=billing_id,
                            water_share=round(water_share, 2),
                            electricity_share=round(electricity_share, 2),
                            wifi_share=round(wifi_share, 2),
                            rent_share=round(rent_share, 2),
                            manual_adjustment=0
                        )
                        success_count += 1
                    except Exception as e:
                        print(f"Error assigning billing to {tenant.get('full_name', '')}: {str(e)}")
                        import traceback
                        traceback.print_exc()
                
                messagebox.showinfo("Success", 
                    f"✓ Billing created and assigned to {success_count}/{len(tenants)} tenant(s)\n\n"
                    f"Unit: {unit_number}\n"
                    f"Utilities (split evenly). Tenant rent uses individual tenant rent when set, otherwise split evenly.\n\n"
                    f"Billing totals:\n"
                    f"  • Water: ₱{float(billing.get('total_water',0) or 0):.2f}\n"
                    f"  • Electricity: ₱{float(billing.get('total_electricity',0) or 0):.2f}\n"
                    f"  • WiFi: ₱{float(billing.get('total_wifi',0) or 0):.2f}\n"
                    f"  • Rent (unit total): ₱{float(billing.get('rent',0) or 0):.2f}")
                dialog.destroy()
                self.show_billings()
            except Exception as e:
                error_msg = str(e)
                print(f"Error in save: {error_msg}")
                import traceback
                traceback.print_exc()
                
                # Provide helpful error messages
                if "UNIQUE constraint failed" in error_msg and "billings" in error_msg:
                    messagebox.showerror("Error", 
                        f"A billing for this unit and month already exists.\n\n"
                        f"Please choose a different month or unit.")
                else:
                    messagebox.showerror("Error", f"Failed to create billing: {error_msg}")
        
        ctk.CTkButton(
            content,
            text="💾 Create & Assign Billing",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x", pady=20)
    
    def _edit_billing_dialog(self, billing):
        """Edit billing dialog"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Edit Billing")
        dialog.geometry("500x650")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Billing info (read-only)
        ctk.CTkLabel(
            content,
            text="Billing Information",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        info_text = f"Unit: {billing['unit_number']}\nMonth: {billing['billing_month']}\nDue Date: {billing['due_date']}"
        ctk.CTkLabel(
            content,
            text=info_text,
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_SECONDARY
        ).pack(anchor="w", pady=(0, 20), padx=10)
        
        # Editable fields
        fields = [
            ("Water Cost (₱)", "total_water", billing['total_water']),
            ("Electricity Cost (₱)", "total_electricity", billing['total_electricity']),
            ("WiFi Cost (₱)", "total_wifi", billing['total_wifi']),
            ("Rent (₱)", "rent", billing['rent']),
        ]
        
        entries = {}
        for label, key, value in fields:
            ctk.CTkLabel(
                content,
                text=label,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_PRIMARY
            ).pack(anchor="w", pady=(12, 5))
            
            entry = ctk.CTkEntry(
                content,
                height=40,
                font=Config.FONT_SMALL,
                fg_color=Config.BG_CARD,
                text_color=Config.TEXT_PRIMARY,
                border_color=Config.PRIMARY_COLOR,
                border_width=2,
                corner_radius=6
            )
            entry.insert(0, str(value))
            entry.pack(fill="x", pady=(0, 10))
            entries[key] = entry
        
        def save():
            try:
                self.backend.update_billing(
                    billing['id'],
                    total_water=float(entries['total_water'].get()) if entries['total_water'].get() else 0,
                    total_electricity=float(entries['total_electricity'].get()) if entries['total_electricity'].get() else 0,
                    total_wifi=float(entries['total_wifi'].get()) if entries['total_wifi'].get() else 0,
                    rent=float(entries['rent'].get()) if entries['rent'].get() else 0
                )
                messagebox.showinfo("Success", "✓ Billing updated successfully!")
                dialog.destroy()
                self.show_billings()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update billing: {str(e)}")
        
        buttons_frame = ctk.CTkFrame(content, fg_color=Config.BG_DARKER)
        buttons_frame.pack(fill="x", pady=20)
        
        ctk.CTkButton(
            buttons_frame,
            text="💾 Save Changes",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x", pady=(0, 10))
        
        ctk.CTkButton(
            buttons_frame,
            text="❌ Cancel",
            command=dialog.destroy,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.TEXT_SECONDARY,
            hover_color="#555",
            height=45,
            corner_radius=6
        ).pack(fill="x")
    
    def _delete_billing(self, billing):
        """Delete billing with confirmation"""
        result = messagebox.askyesno(
            "Confirm Delete",
            f"Are you sure you want to delete the billing for Unit {billing['unit_number']} - {billing['billing_month']}?\n\n"
            f"This will also delete all associated tenant billings and payments.\n\n"
            f"This action cannot be undone."
        )
        
        if result:
            try:
                # Delete all tenant_billings for this billing
                tenant_billings = self.backend.get_all_tenant_billings()
                for tb in tenant_billings:
                    if tb['billing_id'] == billing['id']:
                        self.backend.delete_tenant_billing(tb['id'])
                
                # Delete the billing
                self.backend.delete_billing(billing['id'])
                
                messagebox.showinfo("Success", "✓ Billing deleted successfully!")
                self.show_billings()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete billing: {str(e)}")
    
    def show_tenant_billings(self):
        """Show tenant billings view (all tenant-level billing assignments)"""
        self._clear_content()
        
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="📊 Tenant Billings",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        ctk.CTkButton(
            title_frame,
            text="🔄 Refresh",
            command=self.show_tenant_billings,
            font=Config.FONT_SMALL,
            fg_color=Config.SECONDARY_COLOR,
            hover_color="#5A3A7A",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        # Fetch normal (non-negative) tenant billings
        tenant_billings = self.backend.get_all_tenant_billings()

        # Fetch negative/credit tenant billings and show a top summary box if any
        negative_billings = self.backend.get_negative_tenant_billings()
        if negative_billings:
            total_negative = sum(tb.get('total_amount', 0) for tb in negative_billings)
            neg_frame = ctk.CTkFrame(self.content_frame, fg_color="#1E293B", corner_radius=12)
            neg_frame.pack(fill="x", pady=(0, 12))
            neg_content = ctk.CTkFrame(neg_frame, fg_color="#1E293B")
            neg_content.pack(fill="both", expand=True, padx=12, pady=12)

            ctk.CTkLabel(
                neg_content,
                text=f"🔷 Credits / Negative Bills: {len(negative_billings)} item(s) | Total: ₱{total_negative:,.2f}",
                font=Config.FONT_BODY,
                text_color="#9AA7C1"
            ).pack(side="left", anchor="w")

            def _open_negative_dialog():
                dlg = ctk.CTkToplevel(self)
                dlg.title("Negative Tenant Billings (Credits)")
                dlg.geometry("700x400")

                header = ctk.CTkLabel(dlg, text=f"Negative/credit billings ({len(negative_billings)})", font=Config.FONT_TITLE)
                header.pack(pady=(12, 6))

                container = ctk.CTkScrollableFrame(dlg, fg_color=Config.BG_CARD)
                container.pack(fill="both", expand=True, padx=12, pady=8)

                for nb in negative_billings:
                    try:
                        tenant = self.backend.get_tenant(nb['tenant_id']) or {'full_name': 'Unknown'}
                        billing = self.backend.get_billing(nb['billing_id']) or {'unit_number': 'Unknown', 'billing_month': 'Unknown'}
                        entry = ctk.CTkFrame(container, fg_color=Config.BG_DARK, corner_radius=8)
                        entry.pack(fill="x", pady=6, padx=6)
                        ctk.CTkLabel(entry, text=f"👤 {tenant.get('full_name')} | Unit {billing.get('unit_number')} | {billing.get('billing_month')}", font=Config.FONT_BODY, text_color=Config.TEXT_PRIMARY).pack(anchor="w", padx=10, pady=(8, 0))
                        ctk.CTkLabel(entry, text=f"Amount: ₱{nb.get('total_amount', 0):,.2f}", font=Config.FONT_SMALL, text_color=Config.TEXT_SECONDARY).pack(anchor="w", padx=10, pady=(0, 8))
                    except Exception as e:
                        print(f"Error showing negative billing entry: {str(e)}")

                ctk.CTkButton(dlg, text="Close", command=dlg.destroy, fg_color=Config.PRIMARY_COLOR).pack(pady=10)

            ctk.CTkButton(neg_content, text="View Credits", command=_open_negative_dialog, fg_color=Config.INFO_COLOR, width=120).pack(side="right")

        if not tenant_billings:
            ctk.CTkLabel(
                self.content_frame,
                text="No tenant billings found",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        for tb in tenant_billings:
            try:
                # Get tenant info
                tenant = self.backend.get_tenant(tb['tenant_id'])
                billing = self.backend.get_billing(tb['billing_id'])
                
                card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
                card.pack(fill="x", pady=10)
                
                content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
                content.pack(fill="both", expand=True, padx=20, pady=15)
                
                # Header
                header_text = f"👤 {tenant['full_name']} | Unit {billing['unit_number']} | {billing['billing_month']}"
                ctk.CTkLabel(
                    content,
                    text=header_text,
                    font=Config.FONT_SUBTITLE,
                    text_color=Config.ACCENT_COLOR
                ).pack(anchor="w")
                
                # Breakdown
                breakdown = f"💧 Water: ₱{tb['water_share']:.2f} | ⚡ Electricity: ₱{tb['electricity_share']:.2f} | 📡 WiFi: ₱{tb['wifi_share']:.2f} | 🏠 Rent: ₱{tb['rent_share']:.2f}"
                ctk.CTkLabel(
                    content,
                    text=breakdown,
                    font=Config.FONT_SMALL,
                    text_color=Config.TEXT_SECONDARY
                ).pack(anchor="w", pady=(5, 8))
                
                # Total and status
                # Treat internal 'pending' status as 'unpaid' for display
                is_unpaid_like = tb['status'] in ('unpaid', 'pending', 'partially_paid')
                status_color = Config.SUCCESS_COLOR if tb['status'] == 'paid' else (
                    Config.SECONDARY_COLOR if is_unpaid_like else "#FF9500"
                )
                display_status = 'UNPAID' if tb['status'] == 'pending' else tb['status'].upper()
                status_text = f"💰 Total: ₱{tb['total_amount']:.2f} | Status: {display_status}"
                ctk.CTkLabel(
                    content,
                    text=status_text,
                    font=("Segoe UI", 12, "bold"),
                    text_color=status_color
                ).pack(anchor="w")
                
            except Exception as e:
                print(f"Error displaying tenant billing: {str(e)}")
    
    def show_payments(self):
        """Show payments view with billing linkage"""
        self._clear_content()
        
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="💳 Payment Management",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        buttons_frame = ctk.CTkFrame(title_frame, fg_color=Config.BG_DARK)
        buttons_frame.pack(side="right")
        
        # (Advanced Payment moved to sidebar)
        
        ctk.CTkButton(
            buttons_frame,
            text="💰 Record Payment",
            command=self._add_payment_dialog,
            font=Config.FONT_SMALL,
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=40,
            corner_radius=6
        ).pack(side="right")
        
        payments = self.backend.get_all_payments()
        
        if not payments:
            ctk.CTkLabel(
                self.content_frame,
                text="No payments recorded",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        for payment in payments:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            card.pack(fill="x", pady=10)
            
            content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            content.pack(fill="both", expand=True, padx=20, pady=15)
            
            # Get tenant name for better display
            try:
                tenant = self.backend.get_tenant(payment['tenant_id'])
                tenant_name = tenant['full_name'] if tenant else f"Tenant {payment['tenant_id']}"
            except:
                tenant_name = f"Tenant {payment['tenant_id']}"
            
            ctk.CTkLabel(
                content,
                text=f"💳 {tenant_name} - {payment['billing_month']}",
                font=Config.FONT_SUBTITLE,
                text_color=Config.ACCENT_COLOR
            ).pack(anchor="w")
            
            ctk.CTkLabel(
                content,
                text=f"✓ Amount: ₱{payment['amount_paid']:,.2f}",
                font=("Segoe UI", 14, "bold"),
                text_color=Config.SUCCESS_COLOR
            ).pack(anchor="w", pady=(5, 3))
            
            details = f"📌 Method: {payment['payment_method'].upper()} | 📅 {payment['payment_date']}"
            ctk.CTkLabel(
                content,
                text=details,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w")
    
    def _add_payment_dialog(self):
        """Add payment dialog with billing selection and payment history"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Record New Payment")
        dialog.geometry("700x900")
        dialog.resizable(True, True)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        entries = {}
        billing_map = {}
        payment_history_frame = None
        
        # Get all active tenants
        tenants = self.backend.get_all_tenants()
        active_tenants = [t for t in tenants if t.get('active', 1) == 1]
        
        # Create tenant options and mapping
        tenant_options = [f"{t['full_name']} (Unit {t['unit_number']})" for t in active_tenants]
        tenant_map = {f"{t['full_name']} (Unit {t['unit_number']})": t for t in active_tenants}
        
        if not tenant_options:
            tenant_options = ["No active tenants available"]
        
        # Tenant Selection
        ctk.CTkLabel(
            content,
            text="Select Tenant",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        tenant_var = ctk.StringVar(value=tenant_options[0])
        tenant_dropdown = ctk.CTkComboBox(
            content,
            values=tenant_options,
            variable=tenant_var,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            state="readonly"
        )
        tenant_dropdown.pack(fill="x", pady=(0, 20))
        
        # Tenant Info display (read-only)
        ctk.CTkLabel(
            content,
            text="Tenant Info",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        tenant_info_display = ctk.CTkLabel(
            content,
            text="ID: - | Unit: - | Email: -",
            font=Config.FONT_BODY,
            text_color=Config.INFO_COLOR
        )
        tenant_info_display.pack(anchor="w", pady=(0, 15))
        
        # Pending Billings Section
        ctk.CTkLabel(
            content,
            text="Select Billing to Pay",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        billing_options = ["Select a billing..."]
        billing_var = ctk.StringVar(value=billing_options[0])
        billing_dropdown = ctk.CTkComboBox(
            content,
            values=billing_options,
            variable=billing_var,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            state="readonly"
        )
        billing_dropdown.pack(fill="x", pady=(0, 15))
        
        # Amount Due Display
        ctk.CTkLabel(
            content,
            text="Amount Due",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        amount_due_display = ctk.CTkLabel(
            content,
            text="₱0.00",
            font=("Segoe UI", 16, "bold"),
            text_color=Config.DANGER_COLOR
        )
        amount_due_display.pack(anchor="w", pady=(0, 15))
        
        # Amount Paid
        ctk.CTkLabel(
            content,
            text="Amount to Pay (₱)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['amount_paid'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6
        )
        entries['amount_paid'].pack(fill="x", pady=(0, 20))
        
        # Advance Payment Section (balance + source choice)
        ctk.CTkLabel(
            content,
            text="Advance Payment Balance",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        advance_balance_display = ctk.CTkLabel(
            content,
            text="₱0.00",
            font=("Segoe UI", 12, "bold"),
            text_color=Config.SUCCESS_COLOR
        )
        advance_balance_display.pack(anchor="w", pady=(0, 5))

        # Payment source choice: Auto (use advance if available), Advance only, or Cash only
        ctk.CTkLabel(
            content,
            text="Payment Source",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(8, 6))

        payment_source_var = ctk.StringVar(value="auto")
        radio_frame = ctk.CTkFrame(content, fg_color=Config.BG_DARKER)
        radio_frame.pack(fill="x", pady=(0, 12))
        
        ctk.CTkRadioButton(radio_frame, text="Advance Only (deduct advance balance)", variable=payment_source_var, value="advance", font=Config.FONT_SMALL).pack(anchor="w", pady=4, padx=8)
        ctk.CTkRadioButton(radio_frame, text="Cash / Other (do not use advance)", variable=payment_source_var, value="cash", font=Config.FONT_SMALL).pack(anchor="w", pady=4, padx=8)
        
        # Payment History Section
        ctk.CTkLabel(
            content,
            text="📋 Payment History for Selected Tenant",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(20, 10))
        
        payment_history_frame = ctk.CTkFrame(content, fg_color=Config.BG_CARD, corner_radius=8)
        payment_history_frame.pack(fill="both", expand=True, pady=(0, 20))
        
        payment_history_label = ctk.CTkLabel(
            payment_history_frame,
            text="Select a tenant to view payment history",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_SECONDARY
        )
        payment_history_label.pack(padx=15, pady=15)
        
        def update_payment_history():
            """Update payment history display"""
            nonlocal payment_history_frame, payment_history_label
            
            for widget in payment_history_frame.winfo_children():
                widget.destroy()
            
            selected = tenant_var.get()
            if selected in tenant_map:
                tenant = tenant_map[selected]
                tenant_id = tenant['id']
                
                try:
                    # Get all payments for this tenant
                    all_payments = self.backend.get_all_payments()
                    tenant_payments = [p for p in all_payments if p['tenant_id'] == tenant_id]
                    
                    if tenant_payments:
                        # Sort by payment date descending (most recent first)
                        tenant_payments.sort(key=lambda x: x['payment_date'], reverse=True)
                        
                        # Create header
                        header = ctk.CTkFrame(payment_history_frame, fg_color=Config.BG_CARD)
                        header.pack(fill="x", padx=10, pady=10)
                        
                        ctk.CTkLabel(header, text="📅 Date", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY, width=60).pack(side="left", padx=5)
                        ctk.CTkLabel(header, text="💰 Amount", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY, width=80).pack(side="left", padx=5)
                        ctk.CTkLabel(header, text="📌 Method", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY, width=70).pack(side="left", padx=5)
                        ctk.CTkLabel(header, text="📊 Month", font=Config.FONT_SMALL, text_color=Config.TEXT_PRIMARY).pack(side="left", padx=5, fill="x", expand=True)
                        
                        # Display each payment
                        for payment in tenant_payments[:10]:  # Show last 10 payments
                            payment_row = ctk.CTkFrame(payment_history_frame, fg_color=Config.BG_DARKER, corner_radius=6)
                            payment_row.pack(fill="x", padx=10, pady=5)
                            
                            ctk.CTkLabel(
                                payment_row,
                                text=payment['payment_date'],
                                font=Config.FONT_SMALL,
                                text_color=Config.SUCCESS_COLOR,
                                width=60
                            ).pack(side="left", padx=8, pady=8)
                            
                            ctk.CTkLabel(
                                payment_row,
                                text=f"₱{payment['amount_paid']:,.2f}",
                                font=("Segoe UI", 11, "bold"),
                                text_color=Config.SUCCESS_COLOR,
                                width=80
                            ).pack(side="left", padx=8, pady=8)
                            
                            ctk.CTkLabel(
                                payment_row,
                                text=payment['payment_method'].upper(),
                                font=Config.FONT_SMALL,
                                text_color=Config.TEXT_SECONDARY,
                                width=70
                            ).pack(side="left", padx=8, pady=8)
                            
                            ctk.CTkLabel(
                                payment_row,
                                text=payment['billing_month'],
                                font=Config.FONT_SMALL,
                                text_color=Config.TEXT_SECONDARY
                            ).pack(side="left", padx=8, pady=8, fill="x", expand=True)
                    else:
                        ctk.CTkLabel(
                            payment_history_frame,
                            text="✓ No payments recorded yet",
                            font=Config.FONT_SMALL,
                            text_color=Config.TEXT_SECONDARY
                        ).pack(padx=15, pady=15)
                except Exception as e:
                    ctk.CTkLabel(
                        payment_history_frame,
                        text=f"Error loading history: {str(e)}",
                        font=Config.FONT_SMALL,
                        text_color=Config.DANGER_COLOR
                    ).pack(padx=15, pady=15)
        
        def update_pending_billings(*args):
            """Update pending billings when tenant is selected"""
            selected = tenant_var.get()
            if selected in tenant_map:
                tenant = tenant_map[selected]
                tenant_info_display.configure(text=f"ID: {tenant['id']} | Unit: {tenant['unit_number']} | Email: {tenant['email']}")
                
                try:
                    # Get pending billings
                    pending = self.backend.get_pending_billings(tenant['id'])
                    billing_options_new = [f"{b['billing_month']} - ₱{b['amount_due']:.2f} due (Due: {b['due_date']})" for b in pending]
                    billing_map.clear()

                    # Update advance balance display
                    try:
                        adv = self.backend.get_tenant_advanced_payment(tenant['id'])
                        advance_balance_display.configure(text=f"₱{adv:,.2f}")
                    except Exception:
                        advance_balance_display.configure(text="₱0.00")

                    if billing_options_new:
                        for b in pending:
                            key = f"{b['billing_month']} - ₱{b['amount_due']:.2f} due (Due: {b['due_date']})"
                            billing_map[key] = b
                        billing_dropdown.configure(values=billing_options_new)
                        billing_var.set(billing_options_new[0])
                        update_amount_due()  # Trigger amount update
                    else:
                        billing_dropdown.configure(values=["No pending billings"])
                        billing_var.set("No pending billings")
                        amount_due_display.configure(text="₱0.00")
                        entries['amount_paid'].delete(0, "end")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to load billings: {str(e)}")
                    billing_dropdown.configure(values=["Error loading billings"])
                    billing_var.set("Error loading billings")
                
                # Update payment history
                update_payment_history()

        def _on_payment_source_change(*args):
            """Enable/disable amount entry based on payment source selection"""
            src = payment_source_var.get()
            sel = billing_var.get()
            if src == 'advance':
                # Advance only: set amount to 0 and disable manual editing
                entries['amount_paid'].delete(0, 'end')
                entries['amount_paid'].insert(0, '0')
                try:
                    entries['amount_paid'].configure(state='disabled')
                except Exception:
                    pass
            else:
                # Auto or cash: enable editing and prefill billing amount
                try:
                    entries['amount_paid'].configure(state='normal')
                except Exception:
                    pass
                update_amount_due()

        payment_source_var.trace_add('write', _on_payment_source_change)
        
        def update_amount_due(*args):
            """Update amount due when billing is selected"""
            selected = billing_var.get()
            if selected in billing_map:
                billing = billing_map[selected]
                original_due = float(billing['amount_due'] or 0)
                amount_due_display.configure(text=f"₱{original_due:,.2f}")
                # Keep the amount input equal to the billing amount regardless of advance checkbox.
                entries['amount_paid'].delete(0, "end")
                entries['amount_paid'].insert(0, str(original_due))
            else:
                amount_due_display.configure(text="₱0.00")
                entries['amount_paid'].delete(0, "end")

        # Checking 'Use Advance' no longer changes the prefilled amount; backend will apply advance on save.
        
        tenant_var.trace("w", update_pending_billings)
        billing_var.trace("w", update_amount_due)
        update_pending_billings()  # Initialize on load
        
        def save():
            try:
                selected_tenant = tenant_var.get()
                selected_billing = billing_var.get()
                
                if selected_tenant not in tenant_map:
                    messagebox.showerror("Error", "Please select a valid tenant")
                    return
                
                if selected_billing not in billing_map:
                    messagebox.showerror("Error", "Please select a billing to pay")
                    return
                
                amount_str = entries['amount_paid'].get()
                if not amount_str:
                    messagebox.showerror("Error", "Please enter payment amount")
                    return
                
                try:
                    amount_paid = float(amount_str)
                except ValueError:
                    messagebox.showerror("Error", "Please enter a valid number")
                    return
                
                # Validate zero amount only allowed when advance-only or auto with advance
                if amount_paid == 0 and payment_source_var.get() == 'cash':
                    messagebox.showerror("Error", "Payment amount cannot be zero for cash payments")
                    return
                
                if amount_paid < 0:
                    result = messagebox.askyesno("Negative Amount", 
                        "This is a credit/refund (negative amount).\n"
                        "It will be added to the tenant's advance payment balance.\n\n"
                        "Continue?")
                    if not result:
                        return
                
                
                # Note: Advance payment application is handled server-side when a tenant_billing_id is provided.
                tenant = tenant_map[selected_tenant]
                # Determine apply_advance based on payment source choice
                src = payment_source_var.get()
                if src == 'advance':
                    apply_advance = True
                    # ensure amount_paid is zero when advance-only
                    amount_paid = 0
                elif src == 'cash':
                    apply_advance = False
                else:  # auto
                    apply_advance = True
                
                billing = billing_map[selected_billing]
                
                self.backend.record_payment(
                    tenant_id=tenant['id'],
                    billing_month=billing['billing_month'],
                    amount_paid=amount_paid,
                    payment_method="cash",
                    tenant_billing_id=billing.get('tenant_billing_id'),
                    apply_advance=apply_advance
                )
                
                message = "✓ Credit recorded successfully!" if amount_paid < 0 else "✓ Payment recorded successfully!"
                message += "\n\n✅ All information updated:"
                message += "\n• Billing status updated to PAID"

                message += "\n• Tenant billing assignments refreshed"
                message += "\n• Collection summary updated"
                message += "\n• Dashboard refreshed"
                
                messagebox.showinfo("Success", message)
                dialog.destroy()
                
                # Refresh all views to show complete updates
                self.show_payments()
                self.show_tenant_billings()
                self.show_dashboard()
                self.show_billings()
            except ValueError as e:
                messagebox.showerror("Error", f"Invalid input: {str(e)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to record payment: {str(e)}")
        
        ctk.CTkButton(
            content,
            text="💾 Save Payment",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x", pady=(0, 10))
    
    def _add_advanced_payment_dialog(self):
        """Advanced payment dialog - deposit credits for future billing"""
        dialog = ctk.CTkToplevel(self)
        dialog.title("Advanced Payment - Deposit Credits")
        dialog.geometry("600x650")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=Config.BG_DARKER)
        
        content = ctk.CTkScrollableFrame(dialog, fg_color=Config.BG_DARKER)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        entries = {}
        
        # Get all active tenants
        tenants = self.backend.get_all_tenants()
        active_tenants = [t for t in tenants if t.get('active', 1) == 1]
        
        # Create tenant options and mapping
        tenant_options = [f"{t['full_name']} (Unit {t['unit_number']})" for t in active_tenants]
        tenant_map = {f"{t['full_name']} (Unit {t['unit_number']})": t for t in active_tenants}
        
        if not tenant_options:
            tenant_options = ["No active tenants available"]
        
        # Tenant Selection
        ctk.CTkLabel(
            content,
            text="Select Tenant",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        tenant_var = ctk.StringVar(value=tenant_options[0])
        tenant_dropdown = ctk.CTkComboBox(
            content,
            values=tenant_options,
            variable=tenant_var,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            state="readonly"
        )
        tenant_dropdown.pack(fill="x", pady=(0, 20))
        
        # Current Advanced Payment Display
        ctk.CTkLabel(
            content,
            text="Current Advanced Payment Balance",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        balance_label = ctk.CTkLabel(
            content,
            text="₱0.00",
            font=("Segoe UI", 16, "bold"),
            text_color=Config.ACCENT_COLOR
        )
        balance_label.pack(anchor="w", pady=(0, 20))
        
        # Info box
        info_frame = ctk.CTkFrame(content, fg_color=Config.BG_CARD, corner_radius=8)
        info_frame.pack(fill="x", pady=(0, 20))
        
        info_content = ctk.CTkFrame(info_frame, fg_color=Config.BG_CARD)
        info_content.pack(fill="both", expand=True, padx=15, pady=10)
        
        ctk.CTkLabel(
            info_content,
            text="💡 How Advanced Payment Works:",
            font=("Segoe UI", 12, "bold"),
            text_color=Config.INFO_COLOR
        ).pack(anchor="w", pady=(0, 8))
        
        ctk.CTkLabel(
            info_content,
            text="• Deposit credits in advance\n"
                "• Credits are applied to future billings\n"
                "• When billing is due, credits reduce charges\n"
                "• No billing created for months paid in advance",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_SECONDARY
        ).pack(anchor="w")
        
        # Amount to deposit
        ctk.CTkLabel(
            content,
            text="Amount to Deposit (₱)",
            font=Config.FONT_SMALL,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(12, 5))
        
        entries['amount'] = ctk.CTkEntry(
            content,
            height=40,
            font=Config.FONT_SMALL,
            fg_color=Config.BG_CARD,
            text_color=Config.TEXT_PRIMARY,
            border_color=Config.PRIMARY_COLOR,
            border_width=2,
            corner_radius=6,
            placeholder_text="Enter amount"
        )
        entries['amount'].pack(fill="x", pady=(0, 20))
        
        # (Payment Method removed - uses default)
        
        def update_balance(*args):
            """Update balance display when tenant is selected"""
            selected = tenant_var.get()
            if selected in tenant_map:
                tenant = tenant_map[selected]
                try:
                    balance = self.backend.get_tenant_advanced_payment(tenant['id'])
                    balance_label.configure(text=f"₱{balance:,.2f}")
                except:
                    balance_label.configure(text="₱0.00")
        
        tenant_var.trace("w", update_balance)
        update_balance()
        
        def save():
            try:
                selected_tenant = tenant_var.get()
                if selected_tenant not in tenant_map:
                    messagebox.showerror("Error", "Please select a valid tenant")
                    return
                
                amount_str = entries['amount'].get().strip()
                if not amount_str:
                    messagebox.showerror("Error", "Please enter an amount")
                    return
                
                amount = float(amount_str)
                if amount <= 0:
                    messagebox.showerror("Error", "Amount must be greater than 0")
                    return
                
                tenant = tenant_map[selected_tenant]
                
                # Record advanced payment
                success = self.backend.handle_advanced_payment(
                    tenant_id=tenant['id'],
                    amount=amount,
                    payment_method="cash"
                )
                
                if success:
                    messagebox.showinfo(
                        "Success",
                        f"✓ Advanced payment deposited!\n"
                        f"Amount: ₱{amount:,.2f}\n"
                        f"This credit will be applied to future billings."
                    )
                    dialog.destroy()
                    self.show_payments()
                else:
                    messagebox.showerror("Error", "Failed to record advanced payment")
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid amount")
            except Exception as e:
                messagebox.showerror("Error", f"Error: {str(e)}")
        
        ctk.CTkButton(
            content,
            text="💾 Deposit Advanced Payment",
            command=save,
            font=("Segoe UI", 12, "bold"),
            fg_color=Config.SUCCESS_COLOR,
            hover_color="#38A169",
            height=45,
            corner_radius=6
        ).pack(fill="x", pady=(0, 10))
    
    def show_collection_summary(self):
        """Show detailed collection summary with billing stats and auto-refresh"""
        self._clear_content()
        
        # Title with refresh and filter options
        title_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        title_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(
            title_frame,
            text="📊 Collection Summary",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(side="left")
        
        btn_frame = ctk.CTkFrame(title_frame, fg_color=Config.BG_DARK)
        btn_frame.pack(side="right")
        
        ctk.CTkButton(
            btn_frame,
            text="🔄 Refresh",
            command=self.show_collection_summary,
            font=Config.FONT_SMALL,
            fg_color=Config.SECONDARY_COLOR,
            hover_color="#5A3A7A",
            height=40,
            corner_radius=6
        ).pack(side="right", padx=(10, 0))
        
        current_month = datetime.now().strftime("%Y-%m")
        summary = self.backend.get_collection_summary(current_month)
        
        # Main summary cards
        data = [
            (f"📅 Billing Month: {current_month}", Config.INFO_COLOR),
            (f"📋 Total Billings: {summary['total_billings']}", Config.PRIMARY_COLOR),
            (f"💰 Total Amount Due: ₱{summary['total_amount_due']:,.2f}", Config.WARNING_COLOR),
            (f"✅ Amount Collected: ₱{summary['amount_collected']:,.2f}", Config.SUCCESS_COLOR),
            (f"❌ Outstanding: ₱{summary['amount_outstanding']:,.2f}", Config.DANGER_COLOR),
            (f"📈 Collection Rate: {summary['collection_rate']}%", Config.INFO_COLOR),
        ]
        
        for text, color in data:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=12)
            card.pack(fill="x", pady=12)
            
            content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            content.pack(fill="both", expand=True, padx=20, pady=15)
            
            ctk.CTkLabel(
                content,
                text=text,
                font=("Segoe UI", 16, "bold"),
                text_color=color
            ).pack(anchor="w")
        
        # Billing Statistics
        ctk.CTkLabel(
            self.content_frame,
            text="📊 Billing Statistics",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        all_billings = self.backend.get_all_tenant_billings()
        pending_billings = [b for b in all_billings if b.get('status') == 'pending']
        partial_billings = [b for b in all_billings if b.get('status') == 'partial']
        paid_billings = [b for b in all_billings if b.get('status') == 'paid']
        
        total_pending_amount = sum(b.get('total_amount', 0) for b in pending_billings)
        total_partial_amount = sum(b.get('total_amount', 0) for b in partial_billings)
        
        billing_stats = [
            (f"🔴 Pending: {len(pending_billings)} | Amount: ₱{total_pending_amount:,.2f}", Config.WARNING_COLOR),
            (f"🟡 Partial: {len(partial_billings)} | Amount: ₱{total_partial_amount:,.2f}", Config.INFO_COLOR),
            (f"🟢 Paid: {len(paid_billings)}", Config.SUCCESS_COLOR),
        ]
        
        for text, color in billing_stats:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=8)
            card.pack(fill="x", pady=5)
            
            ctk.CTkLabel(
                card,
                text=text,
                font=Config.FONT_BODY,
                text_color=color
            ).pack(padx=20, pady=10, anchor="w")
    
    def show_payment_history(self):
        """Show payment history"""
        self._clear_content()
        
        ctk.CTkLabel(
            self.content_frame,
            text="💳 Payment History",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 20))
        
        payments = self.backend.get_all_payments()
        
        if not payments:
            ctk.CTkLabel(
                self.content_frame,
                text="No payment history",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        # Header
        header = ctk.CTkFrame(self.content_frame, fg_color=Config.PRIMARY_COLOR, corner_radius=8)
        header.pack(fill="x", pady=(0, 10))
        
        headers = [("Tenant", 'tenant'), ("Month", 'month'), ("Amount", 'amount'), ("Method", 'method'), ("Date", 'date')]
        for label_text, key in headers:
            ctk.CTkLabel(
                header,
                text=label_text,
                font=("Segoe UI", 10, "bold"),
                text_color=Config.TEXT_PRIMARY,
                width=Config.TABLE_COL_WIDTHS.get(key, 120)
            ).pack(side="left", padx=12, pady=10)
        
        # Rows
        for i, payment in enumerate(payments):
            row_bg = Config.BG_CARD if i % 2 == 0 else Config.BG_DARKER
            row = ctk.CTkFrame(self.content_frame, fg_color=row_bg, corner_radius=6)
            row.pack(fill="x", pady=2)
            
            # Resolve tenant name from tenant_id
            try:
                tenant = self.backend.get_tenant(payment['tenant_id'])
                tenant_display = tenant.get('full_name') if tenant and tenant.get('full_name') else f"Tenant {payment['tenant_id']}"
            except Exception:
                tenant_display = f"Tenant {payment['tenant_id']}"

            ctk.CTkLabel(row, text=tenant_display, text_color=Config.TEXT_PRIMARY, font=Config.FONT_SMALL, width=Config.TABLE_COL_WIDTHS.get('tenant', 200)).pack(side="left", padx=12, pady=8)
            ctk.CTkLabel(row, text=payment['billing_month'], text_color=Config.TEXT_SECONDARY, font=Config.FONT_SMALL, width=Config.TABLE_COL_WIDTHS.get('month', 120)).pack(side="left", padx=12, pady=8)
            ctk.CTkLabel(row, text=f"₱{payment['amount_paid']:,.2f}", text_color=Config.SUCCESS_COLOR, font=Config.FONT_SMALL, width=Config.TABLE_COL_WIDTHS.get('amount', 120)).pack(side="left", padx=12, pady=8)
            ctk.CTkLabel(row, text=payment['payment_method'].upper(), text_color=Config.INFO_COLOR, font=Config.FONT_SMALL, width=Config.TABLE_COL_WIDTHS.get('method', 120)).pack(side="left", padx=12, pady=8)
            ctk.CTkLabel(row, text=payment['payment_date'], text_color=Config.TEXT_MUTED, font=Config.FONT_SMALL, width=Config.TABLE_COL_WIDTHS.get('date', 140)).pack(side="left", padx=12, pady=8)
    
    def show_tenant_stats(self):
        """Show tenant statistics"""
        self._clear_content()
        
        ctk.CTkLabel(
            self.content_frame,
            text="👥 Tenant Statistics",
            font=Config.FONT_HEADING,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(0, 30))
        
        tenants = self.backend.get_all_tenants()
        
        if not tenants:
            ctk.CTkLabel(
                self.content_frame,
                text="No tenants found",
                font=Config.FONT_BODY,
                text_color=Config.TEXT_SECONDARY
            ).pack(pady=40)
            return
        
        # Stats cards
        stats_frame = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_DARK)
        stats_frame.pack(fill="x", pady=20)
        
        total_rent = sum(t['rent_amount'] for t in tenants)
        avg_rent = total_rent / len(tenants) if tenants else 0
        
        self._create_stat_card(stats_frame, "Total Tenants", len(tenants), "👥", Config.PRIMARY_COLOR)
        self._create_stat_card(stats_frame, "Average Rent", f"₱{avg_rent:,.2f}", "📊", Config.INFO_COLOR)
        self._create_stat_card(stats_frame, "Total Monthly Rent", f"₱{total_rent:,.2f}", "💰", Config.SUCCESS_COLOR)
        
        # Tenant list
        ctk.CTkLabel(
            self.content_frame,
            text="Tenant Details",
            font=Config.FONT_SUBTITLE,
            text_color=Config.TEXT_PRIMARY
        ).pack(anchor="w", pady=(30, 15))
        
        for tenant in tenants:
            card = ctk.CTkFrame(self.content_frame, fg_color=Config.BG_CARD, corner_radius=10)
            card.pack(fill="x", pady=8)
            
            content = ctk.CTkFrame(card, fg_color=Config.BG_CARD)
            content.pack(fill="both", expand=True, padx=15, pady=12)
            
            ctk.CTkLabel(
                content,
                text=f"{tenant['full_name']} (Unit {tenant['unit_number']})",
                font=("Segoe UI", 12, "bold"),
                text_color=Config.ACCENT_COLOR
            ).pack(anchor="w")
            
            details = f"Email: {tenant['email']} | Contact: {tenant['contact_number']} | Rent: ₱{tenant['rent_amount']}"
            ctk.CTkLabel(
                content,
                text=details,
                font=Config.FONT_SMALL,
                text_color=Config.TEXT_SECONDARY
            ).pack(anchor="w", pady=(5, 0))
    
    def _logout(self):
        """Logout"""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.destroy()
            self.parent.deiconify()


# ========================= MAIN ENTRY POINT =========================
if __name__ == "__main__":
    app = ModernLoginUI()
    app.mainloop()
